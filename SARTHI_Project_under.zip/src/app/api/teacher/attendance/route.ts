export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { authenticateTeacher } from '@/lib/auth/middleware';
import { API } from '@/lib/api/response';

/**
 * GET /api/teacher/attendance
 * Fetch attendance records for a given date, course, or live session.
 */
export async function GET(request: NextRequest) {
  try {
    const teacherId = await authenticateTeacher(request);
    const { searchParams } = new URL(request.url);
    const dateParam = searchParams.get('date');
    const courseId = searchParams.get('courseId');

    const targetDate = dateParam ? new Date(dateParam) : new Date();
    const startOfDay = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate());
    const endOfDay = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate(), 23, 59, 59, 999);

    const teacher = await prisma.teacher.findUnique({
      where: { userId: teacherId },
      select: { id: true },
    });

    // 1. Identify courses owned by this teacher
    const teacherCourses = await prisma.course.findMany({
      where: {
        OR: [
          { instructorId: teacherId },
          ...(teacher ? [{ teacherId: teacher.id }] : []),
        ],
        ...(courseId && courseId !== 'all' ? { id: courseId } : {}),
      },
      select: { id: true, title: true },
    });
    const courseIds = teacherCourses.map((c) => c.id);

    // 2. Fetch enrolled students for these courses
    const enrollments = await prisma.enrollment.findMany({
      where: {
        courseId: { in: courseIds },
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            image: true,
          },
        },
        course: {
          select: {
            id: true,
            title: true,
          },
        },
      },
    });

    const uniqueStudentIds = Array.from(new Set(enrollments.map((e) => e.userId)));

    // 3. Fetch existing attendance records for the target day
    const records = await prisma.attendance.findMany({
      where: {
        userId: { in: uniqueStudentIds },
        date: { gte: startOfDay, lte: endOfDay },
      },
    });

    const recordMap = new Map(records.map((r) => [r.userId, r]));

    // 4. Map students with their attendance status
    const studentList = uniqueStudentIds.map((userId) => {
      const enrollment = enrollments.find((e) => e.userId === userId);
      const student = enrollment?.user;
      const existing = recordMap.get(userId);

      return {
        id: existing?.id || `att-temp-${userId}`,
        studentId: userId,
        studentName: student?.name || 'Enrolled Student',
        studentEmail: student?.email || '',
        studentAvatar: student?.image || '/images/student-img-1.jpg',
        courseId: enrollment?.courseId || '',
        courseTitle: enrollment?.course?.title || 'Classroom',
        status: existing?.status ? existing.status.toUpperCase() : 'PRESENT',
        remarks: existing?.remarks || '',
        attendanceRate: 92,
      };
    });

    const presentCount = studentList.filter((s) => s.status === 'PRESENT').length;
    const absentCount = studentList.filter((s) => s.status === 'ABSENT').length;
    const lateCount = studentList.filter((s) => s.status === 'LATE').length;
    const totalCount = studentList.length;
    const attendanceRate = totalCount > 0 ? Math.round(((presentCount + lateCount * 0.5) / totalCount) * 100) : 100;

    return API.ok({
      date: startOfDay.toISOString().split('T')[0],
      courses: teacherCourses,
      students: studentList,
      summary: {
        total: totalCount,
        present: presentCount,
        absent: absentCount,
        late: lateCount,
        rate: attendanceRate,
      },
    });
  } catch (error: any) {
    console.error('❌ Attendance GET API Error:', error);
    return API.server('Failed to fetch attendance data');
  }
}

/**
 * POST /api/teacher/attendance
 * Save / upsert classroom attendance records for a batch of students.
 */
export async function POST(request: NextRequest) {
  try {
    const teacherId = await authenticateTeacher(request);
    const body = await request.json();
    const { date, records } = body;

    if (!Array.isArray(records) || records.length === 0) {
      return API.badRequest('Records array is required');
    }

    const targetDate = date ? new Date(date) : new Date();
    const normalizedDate = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate(), 12, 0, 0);

    let updatedCount = 0;
    for (const record of records) {
      if (!record.studentId) continue;
      try {
        await prisma.attendance.upsert({
          where: {
            userId_date: {
              userId: record.studentId,
              date: normalizedDate,
            },
          },
          update: {
            status: (record.status || 'PRESENT').toUpperCase(),
            remarks: record.remarks || null,
            updatedAt: new Date(),
          },
          create: {
            userId: record.studentId,
            date: normalizedDate,
            status: (record.status || 'PRESENT').toUpperCase(),
            remarks: record.remarks || null,
          },
        });
        updatedCount++;
      } catch (upsertErr) {
        try {
          await prisma.attendance.create({
            data: {
              userId: record.studentId,
              date: normalizedDate,
              status: (record.status || 'PRESENT').toUpperCase(),
              remarks: record.remarks || null,
            },
          });
          updatedCount++;
        } catch (e) {}
      }
    }

    return API.ok(
      {
        date: normalizedDate.toISOString().split('T')[0],
        savedCount: updatedCount,
      },
      'Attendance records saved successfully'
    );
  } catch (error: any) {
    console.error('❌ Attendance POST API Error:', error);
    return API.server('Failed to save attendance records');
  }
}
