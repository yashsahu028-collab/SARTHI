"use client";

import React, { useState, useMemo, useEffect } from "react";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import TrainerShell from "@/components/trainer/TrainerShell";
import { useTrainer } from "@/lib/services/TrainerContext";

export default function TrainerQuizStudioPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const actionParam = searchParams?.get("action");
  const editIdParam = searchParams?.get("edit");

  const { quizzes, courses, createQuiz, deleteQuiz, duplicateQuiz } = useTrainer();
  const [searchQuery, setSearchQuery] = useState("");

  // Studio Mode: 'list' | 'builder' | 'preview'
  const [studioMode, setStudioMode] = useState(actionParam === "create" ? "builder" : "list");
  const [selectedCourseFilter, setSelectedCourseFilter] = useState("all");

  // Quiz Builder State (Sections 9, 10, 11)
  const [builderId, setBuilderId] = useState(null);
  const [quizTitle, setQuizTitle] = useState("Algebra Fundamentals — Mid-Term Diagnostic");
  const [quizDescription, setQuizDescription] = useState("Evaluation of linear equations, quadratic discriminants, and factoring principles.");
  const [quizCourseId, setQuizCourseId] = useState(courses[0]?.id || "course-math-10");
  const [quizDurationMinutes, setQuizDurationMinutes] = useState(30);
  const [quizAttempts, setQuizAttempts] = useState(1);
  const [quizPassingScore, setQuizPassingScore] = useState(60);
  const [shuffleQuestions, setShuffleQuestions] = useState(true);

  // Dynamic Questions Array
  const [questions, setQuestions] = useState([
    {
      id: "q-1",
      type: "MCQ",
      question: "What is the solution of 2x + 4 = 10?",
      options: ["2", "3", "4", "5"],
      correctAnswer: 1, // index 1 is "3"
      marks: 2,
      explanation: "Subtract 4 from both sides: 2x = 6, then divide by 2: x = 3.",
    },
    {
      id: "q-2",
      type: "MCQ",
      question: "What is the discriminant of the quadratic equation 2x² - 4x + 2 = 0?",
      options: ["0", "4", "-8", "16"],
      correctAnswer: 0, // index 0 is "0"
      marks: 2,
      explanation: "Δ = b² - 4ac = (-4)² - 4(2)(2) = 16 - 16 = 0.",
    },
    {
      id: "q-3",
      type: "TRUE_FALSE",
      question: "A quadratic equation always has two distinct real roots if the discriminant is greater than zero.",
      options: ["True", "False"],
      correctAnswer: 0, // True
      marks: 1,
      explanation: "When b² - 4ac > 0, the equation yields two distinct real solutions.",
    },
  ]);

  // Student Preview Simulator State (Section 12)
  const [previewQuestionIndex, setPreviewQuestionIndex] = useState(0);
  const [previewSelectedAnswers, setPreviewSelectedAnswers] = useState({});
  const [previewSubmitted, setPreviewSubmitted] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  // If URL has action=create or edit=XYZ
  useEffect(() => {
    if (actionParam === "create") {
      setStudioMode("builder");
    } else if (editIdParam) {
      const existing = quizzes.find((q) => q.id === editIdParam);
      if (existing) {
        setBuilderId(existing.id);
        setQuizTitle(existing.title);
        setQuizDescription(existing.description || "");
        setQuizCourseId(existing.courseId || courses[0]?.id);
        setQuizDurationMinutes(existing.durationMinutes || existing.timeLimitMinutes || 30);
        setQuizPassingScore(existing.passingScore || 60);
        if (existing.questions && existing.questions.length > 0) {
          setQuestions(existing.questions);
        }
        setStudioMode("builder");
      }
    }
  }, [actionParam, editIdParam, quizzes, courses]);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 2500);
  };

  // Question manipulation handlers (Section 11)
  const handleAddQuestion = (type = "MCQ") => {
    const newQ = {
      id: `q-${Date.now()}`,
      type: type,
      question: type === "TRUE_FALSE" ? "State whether the following mathematical theorem holds true." : "Enter question prompt here...",
      options: type === "TRUE_FALSE" ? ["True", "False"] : ["Option A", "Option B", "Option C", "Option D"],
      correctAnswer: 0,
      marks: type === "TRUE_FALSE" ? 1 : 2,
      explanation: "",
    };
    setQuestions([...questions, newQ]);
    showToast(`✓ Added new ${type === "TRUE_FALSE" ? "True/False" : "MCQ"} question`);
  };

  const handleDeleteQuestion = (id) => {
    if (questions.length <= 1) {
      showToast("Quiz must have at least one question.");
      return;
    }
    setQuestions(questions.filter((q) => q.id !== id));
    showToast("Question deleted");
  };

  const handleDuplicateQuestion = (id) => {
    const target = questions.find((q) => q.id === id);
    if (!target) return;
    const duplicated = {
      ...target,
      id: `q-${Date.now()}`,
      question: `${target.question} (Copy)`,
    };
    const index = questions.findIndex((q) => q.id === id);
    const updated = [...questions];
    updated.splice(index + 1, 0, duplicated);
    setQuestions(updated);
    showToast("Question duplicated");
  };

  const handleMoveQuestion = (index, direction) => {
    const targetIndex = index + direction;
    if (targetIndex < 0 || targetIndex >= questions.length) return;
    const updated = [...questions];
    const temp = updated[index];
    updated[index] = updated[targetIndex];
    updated[targetIndex] = temp;
    setQuestions(updated);
  };

  const handleUpdateQuestion = (id, field, value) => {
    setQuestions(
      questions.map((q) => {
        if (q.id === id) {
          return { ...q, [field]: value };
        }
        return q;
      })
    );
  };

  const handleAddOption = (questionId) => {
    setQuestions(
      questions.map((q) => {
        if (q.id === questionId && q.type === "MCQ") {
          return {
            ...q,
            options: [...q.options, `Option ${String.fromCharCode(65 + q.options.length)}`],
          };
        }
        return q;
      })
    );
  };

  const handleRemoveOption = (questionId, optionIndex) => {
    setQuestions(
      questions.map((q) => {
        if (q.id === questionId && q.type === "MCQ" && q.options.length > 2) {
          const newOpts = q.options.filter((_, idx) => idx !== optionIndex);
          const newCorrect = q.correctAnswer >= newOpts.length ? 0 : q.correctAnswer;
          return { ...q, options: newOpts, correctAnswer: newCorrect };
        }
        return q;
      })
    );
  };

  const handleSaveDraft = async () => {
    await createQuiz({
      id: builderId || undefined,
      title: quizTitle,
      description: quizDescription,
      courseId: quizCourseId,
      timeLimitMinutes: quizDurationMinutes,
      durationMinutes: quizDurationMinutes,
      passingScore: quizPassingScore,
      attemptsAllowed: quizAttempts,
      questions: questions,
      isDraft: true,
      status: "draft",
    });
    showToast("✓ Quiz saved as draft");
  };

  const handlePublishQuiz = async () => {
    if (!quizTitle.trim()) {
      showToast("Please provide a quiz title");
      return;
    }
    await createQuiz({
      id: builderId || undefined,
      title: quizTitle,
      description: quizDescription,
      courseId: quizCourseId,
      timeLimitMinutes: quizDurationMinutes,
      durationMinutes: quizDurationMinutes,
      passingScore: quizPassingScore,
      attemptsAllowed: quizAttempts,
      questions: questions,
      isDraft: false,
      status: "published",
    });
    showToast("✓ Quiz published successfully!");
    setTimeout(() => {
      setStudioMode("list");
    }, 1000);
  };

  // Preview simulator scoring
  const previewScoreResult = useMemo(() => {
    let score = 0;
    let max = 0;
    questions.forEach((q, idx) => {
      max += q.marks || 2;
      if (previewSelectedAnswers[idx] === q.correctAnswer) {
        score += q.marks || 2;
      }
    });
    const pct = max > 0 ? Math.round((score / max) * 100) : 0;
    return { score, max, pct, passed: pct >= quizPassingScore };
  }, [questions, previewSelectedAnswers, quizPassingScore]);

  // Filtered quizzes in list mode
  const filteredQuizzes = useMemo(() => {
    return quizzes.filter((q) => {
      const matchSearch =
        q.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (q.courseTitle && q.courseTitle.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchCourse = selectedCourseFilter === "all" || q.courseId === selectedCourseFilter;
      return matchSearch && matchCourse;
    });
  }, [quizzes, searchQuery, selectedCourseFilter]);

  return (
    <TrainerShell searchQuery={searchQuery} setSearchQuery={setSearchQuery} placeholder="Search quizzes, question concepts, or curricula...">
      <div style={{ padding: "28px 36px 64px 36px", maxWidth: "1360px", margin: "0 auto", width: "100%" }}>
        {/* Toast Notification Alert */}
        {toastMessage && (
          <div
            style={{
              position: "fixed",
              bottom: "24px",
              right: "24px",
              background: "#0c211d",
              color: "#ffffff",
              padding: "12px 20px",
              borderRadius: "12px",
              boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
              fontSize: "13.5px",
              fontWeight: "700",
              zIndex: 9999,
              display: "flex",
              alignItems: "center",
              gap: "8px",
            }}
          >
            {toastMessage}
          </div>
        )}

        {/* ==========================================================================
            MODE 1: QUIZ REPOSITORY & CATALOG VIEW
            ========================================================================== */}
        {studioMode === "list" && (
          <div>
            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "28px", flexWrap: "wrap", gap: "16px" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                  <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#10b981" }} />
                  <span style={{ fontSize: "11px", fontWeight: "800", color: "#065f46", letterSpacing: "0.12em", textTransform: "uppercase" }}>
                    EVALUATION & ASSESSMENT STUDIO
                  </span>
                </div>
                <h1 style={{ fontSize: "30px", fontWeight: "800", color: "#0a2920", margin: "0 0 6px 0", letterSpacing: "-0.5px" }}>
                  Quiz & Assessment Studio
                </h1>
                <p style={{ fontSize: "14px", color: "#64748b", margin: 0 }}>
                  Build dynamic multiple-choice assessments, timed tests, and preview student evaluation flows.
                </p>
              </div>

              <button
                type="button"
                className="db-btn-primary"
                onClick={() => {
                  setBuilderId(null);
                  setQuizTitle("New Mathematics Assessment");
                  setQuizDescription("");
                  setStudioMode("builder");
                }}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "8px",
                  padding: "10px 20px",
                  borderRadius: "12px",
                  background: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
                  color: "#ffffff",
                  fontSize: "13.5px",
                  fontWeight: "700",
                  border: "none",
                  cursor: "pointer",
                  boxShadow: "0 4px 12px rgba(5, 150, 105, 0.25)",
                }}
              >
                <span style={{ fontSize: "16px", fontWeight: "900", lineHeight: "1" }}>+</span>
                <span>Create Assessment</span>
              </button>
            </div>

            {/* 3 Top Stat Cards */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                gap: "14px",
                marginBottom: "28px",
              }}
            >
              <div className="edtech-kpi-card">
                <div className="edtech-kpi-header">
                  <div className="edtech-kpi-icon" style={{ background: "#ecfdf5", color: "#059669" }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  </div>
                  <span className="edtech-trend-badge positive">Published</span>
                </div>
                <div>
                  <div className="edtech-kpi-val">{quizzes.length}</div>
                  <div className="edtech-kpi-label">Active Assessments</div>
                </div>
              </div>

              <div className="edtech-kpi-card">
                <div className="edtech-kpi-header">
                  <div className="edtech-kpi-icon" style={{ background: "#eff6ff", color: "#2563eb" }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 14 14"></polyline></svg>
                  </div>
                  <span className="edtech-trend-badge positive">+8 this week</span>
                </div>
                <div>
                  <div className="edtech-kpi-val">{quizzes.reduce((acc, q) => acc + (q.totalAttempts || 12), 0)}</div>
                  <div className="edtech-kpi-label">Submissions Evaluated</div>
                </div>
              </div>

              <div className="edtech-kpi-card">
                <div className="edtech-kpi-header">
                  <div className="edtech-kpi-icon" style={{ background: "#fef3c7", color: "#d97706" }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                  </div>
                  <span className="edtech-trend-badge positive">High Average</span>
                </div>
                <div>
                  <div className="edtech-kpi-val">88%</div>
                  <div className="edtech-kpi-label">Average Cohort Pass Rate</div>
                </div>
              </div>
            </div>

            {/* Filter Bar */}
            <div style={{ display: "flex", gap: "10px", marginBottom: "20px", flexWrap: "wrap", alignItems: "center" }}>
              <span style={{ fontSize: "13px", fontWeight: "700", color: "#64748b" }}>Filter by Course:</span>
              <button
                type="button"
                onClick={() => setSelectedCourseFilter("all")}
                style={{
                  border: "none",
                  padding: "6px 14px",
                  borderRadius: "8px",
                  fontSize: "12.5px",
                  fontWeight: "700",
                  cursor: "pointer",
                  background: selectedCourseFilter === "all" ? "#059669" : "#f1f5f9",
                  color: selectedCourseFilter === "all" ? "#fff" : "#475569",
                }}
              >
                All Courses
              </button>
              {courses.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedCourseFilter(c.id)}
                  style={{
                    border: "none",
                    padding: "6px 14px",
                    borderRadius: "8px",
                    fontSize: "12.5px",
                    fontWeight: "700",
                    cursor: "pointer",
                    background: selectedCourseFilter === c.id ? "#059669" : "#f1f5f9",
                    color: selectedCourseFilter === c.id ? "#fff" : "#475569",
                  }}
                >
                  {c.title}
                </button>
              ))}
            </div>

            {/* Quiz Cards Grid */}
            {filteredQuizzes.length === 0 ? (
              <div style={{ textAlign: "center", padding: "48px 20px", background: "#ffffff", borderRadius: "18px", border: "1px dashed #cbd5e1" }}>
                <div style={{ fontSize: "32px", marginBottom: "10px" }}>📝</div>
                <h3 style={{ fontSize: "16px", fontWeight: "700", color: "#0c211d", margin: "0 0 6px 0" }}>No quizzes yet</h3>
                <p style={{ fontSize: "13px", color: "#64748b", margin: "0 0 16px 0" }}>Create your first quiz for your students.</p>
                <button
                  type="button"
                  onClick={() => setStudioMode("builder")}
                  style={{
                    padding: "8px 18px",
                    borderRadius: "10px",
                    background: "#059669",
                    color: "#fff",
                    fontWeight: "700",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Create Quiz
                </button>
              </div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: "16px" }}>
                {filteredQuizzes.map((quiz) => (
                  <div key={quiz.id} className="session-card">
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div>
                        <div style={{ fontSize: "11px", fontWeight: "800", color: "#059669", textTransform: "uppercase", marginBottom: "4px" }}>
                          {quiz.courseTitle || "Secondary Mathematics"}
                        </div>
                        <h3 style={{ fontSize: "16px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                          {quiz.title}
                        </h3>
                      </div>
                      <span
                        style={{
                          fontSize: "11px",
                          fontWeight: "800",
                          padding: "3px 8px",
                          borderRadius: "999px",
                          background: quiz.status === "draft" ? "#f1f5f9" : "#dcfce7",
                          color: quiz.status === "draft" ? "#64748b" : "#16a34a",
                        }}
                      >
                        {quiz.status === "draft" ? "Draft" : "Published"}
                      </span>
                    </div>

                    <div style={{ background: "#f8faf9", padding: "12px", borderRadius: "12px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", fontSize: "12.5px" }}>
                      <div>
                        <span style={{ color: "#64748b" }}>Questions:</span>{" "}
                        <strong style={{ color: "#0c211d" }}>{quiz.questions?.length || quiz.totalQuestions || 4}</strong>
                      </div>
                      <div>
                        <span style={{ color: "#64748b" }}>Duration:</span>{" "}
                        <strong style={{ color: "#0c211d" }}>{quiz.durationMinutes || quiz.timeLimitMinutes || 30} mins</strong>
                      </div>
                      <div>
                        <span style={{ color: "#64748b" }}>Passing Score:</span>{" "}
                        <strong style={{ color: "#0c211d" }}>{quiz.passingScore || 60}%</strong>
                      </div>
                      <div>
                        <span style={{ color: "#64748b" }}>Attempts:</span>{" "}
                        <strong style={{ color: "#0c211d" }}>{quiz.totalAttempts || 0}</strong>
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: "8px", marginTop: "auto" }}>
                      <button
                        type="button"
                        onClick={() => {
                          setBuilderId(quiz.id);
                          setQuizTitle(quiz.title);
                          setQuizDescription(quiz.description || "");
                          setQuizCourseId(quiz.courseId || courses[0]?.id);
                          setQuizDurationMinutes(quiz.durationMinutes || quiz.timeLimitMinutes || 30);
                          setQuizPassingScore(quiz.passingScore || 60);
                          if (quiz.questions && quiz.questions.length > 0) {
                            setQuestions(quiz.questions);
                          }
                          setStudioMode("builder");
                        }}
                        style={{
                          flex: 1,
                          padding: "8px 12px",
                          borderRadius: "10px",
                          background: "#059669",
                          color: "#fff",
                          fontWeight: "700",
                          fontSize: "12.5px",
                          border: "none",
                          cursor: "pointer",
                        }}
                      >
                        Open in Studio
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          if (quiz.questions && quiz.questions.length > 0) {
                            setQuestions(quiz.questions);
                          }
                          setQuizTitle(quiz.title);
                          setPreviewQuestionIndex(0);
                          setPreviewSelectedAnswers({});
                          setPreviewSubmitted(false);
                          setStudioMode("preview");
                        }}
                        style={{
                          padding: "8px 12px",
                          borderRadius: "10px",
                          background: "#ffffff",
                          border: "1px solid #cbd5e1",
                          color: "#0c211d",
                          fontWeight: "700",
                          fontSize: "12.5px",
                          cursor: "pointer",
                        }}
                      >
                        Preview
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          duplicateQuiz(quiz.id);
                          showToast("✓ Quiz duplicated");
                        }}
                        style={{
                          padding: "8px 10px",
                          borderRadius: "10px",
                          background: "#f1f5f9",
                          border: "none",
                          color: "#475569",
                          cursor: "pointer",
                        }}
                        title="Duplicate Quiz"
                      >
                        ⧉
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ==========================================================================
            MODE 2: QUIZ BUILDER STUDIO (Sections 9, 10, 11)
            ========================================================================== */}
        {studioMode === "builder" && (
          <div>
            {/* Studio Top Action Bar (Section 9) */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "24px",
                flexWrap: "wrap",
                gap: "12px",
                background: "#ffffff",
                padding: "16px 20px",
                borderRadius: "16px",
                border: "1px solid #e8f0eb",
                boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <button
                  type="button"
                  onClick={() => setStudioMode("list")}
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "#059669",
                    fontSize: "13.5px",
                    fontWeight: "700",
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "6px",
                  }}
                >
                  ← Back
                </button>
                <span style={{ color: "#cbd5e1" }}>|</span>
                <h2 style={{ fontSize: "17px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                  Quiz Builder Studio
                </h2>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <button
                  type="button"
                  onClick={handleSaveDraft}
                  style={{
                    padding: "8px 16px",
                    borderRadius: "10px",
                    background: "#f1f5f9",
                    border: "1px solid #cbd5e1",
                    color: "#334155",
                    fontSize: "13px",
                    fontWeight: "700",
                    cursor: "pointer",
                  }}
                >
                  Save Draft
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setPreviewQuestionIndex(0);
                    setPreviewSelectedAnswers({});
                    setPreviewSubmitted(false);
                    setStudioMode("preview");
                  }}
                  style={{
                    padding: "8px 16px",
                    borderRadius: "10px",
                    background: "#ffffff",
                    border: "1px solid #059669",
                    color: "#059669",
                    fontSize: "13px",
                    fontWeight: "700",
                    cursor: "pointer",
                  }}
                >
                  Preview as Student
                </button>

                <button
                  type="button"
                  onClick={handlePublishQuiz}
                  className="db-btn-primary"
                  style={{
                    padding: "8px 20px",
                    borderRadius: "10px",
                    background: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
                    color: "#ffffff",
                    fontSize: "13px",
                    fontWeight: "700",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Publish Quiz
                </button>
              </div>
            </div>

            {/* Dual Column Layout: Quiz Content (Left) & Settings (Right) (Section 9) */}
            <div className="quiz-studio-layout">
              {/* Left Main Column: Quiz Content & Questions */}
              <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
                {/* Quiz Meta Card */}
                <div style={{ background: "#ffffff", border: "1px solid #e8f0eb", borderRadius: "18px", padding: "24px" }}>
                  <div style={{ marginBottom: "16px" }}>
                    <label style={{ display: "block", fontSize: "12px", fontWeight: "800", color: "#64748b", textTransform: "uppercase", marginBottom: "6px" }}>
                      Quiz Title *
                    </label>
                    <input
                      type="text"
                      value={quizTitle}
                      onChange={(e) => setQuizTitle(e.target.value)}
                      placeholder="e.g. Algebra Fundamentals"
                      style={{
                        width: "100%",
                        padding: "10px 14px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "16px",
                        fontWeight: "700",
                        color: "#0c211d",
                        outline: "none",
                      }}
                    />
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: "12px", fontWeight: "800", color: "#64748b", textTransform: "uppercase", marginBottom: "6px" }}>
                      Description & Instructions
                    </label>
                    <textarea
                      rows={2}
                      value={quizDescription}
                      onChange={(e) => setQuizDescription(e.target.value)}
                      placeholder="Provide student instructions, grading rules, or rubric guidelines..."
                      style={{
                        width: "100%",
                        padding: "10px 14px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "13.5px",
                        outline: "none",
                        resize: "vertical",
                      }}
                    />
                  </div>
                </div>

                {/* Question Cards (Section 10) */}
                <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
                  {questions.map((q, idx) => (
                    <div key={q.id} className="quiz-question-card">
                      {/* Question Card Header */}
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "14px", paddingBottom: "10px", borderBottom: "1px solid #f1f5f9" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          <span
                            style={{
                              background: "#059669",
                              color: "#fff",
                              fontSize: "12px",
                              fontWeight: "800",
                              width: "24px",
                              height: "24px",
                              borderRadius: "6px",
                              display: "inline-flex",
                              alignItems: "center",
                              justifyContent: "center",
                            }}
                          >
                            {idx + 1}
                          </span>
                          <span style={{ fontSize: "12.5px", fontWeight: "700", color: "#0c211d" }}>
                            Question {idx + 1}
                          </span>
                          <span style={{ fontSize: "11px", fontWeight: "700", color: "#64748b", background: "#f1f5f9", padding: "2px 8px", borderRadius: "999px" }}>
                            {q.type === "TRUE_FALSE" ? "True / False" : "MCQ"}
                          </span>
                        </div>

                        {/* Toolbar: Up, Down, Duplicate, Delete */}
                        <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                          <button
                            type="button"
                            onClick={() => handleMoveQuestion(idx, -1)}
                            disabled={idx === 0}
                            style={{
                              background: "none",
                              border: "1px solid #e2e8f0",
                              borderRadius: "6px",
                              padding: "4px 8px",
                              cursor: idx === 0 ? "not-allowed" : "pointer",
                              opacity: idx === 0 ? 0.4 : 1,
                            }}
                            title="Move Up"
                          >
                            ▲
                          </button>
                          <button
                            type="button"
                            onClick={() => handleMoveQuestion(idx, 1)}
                            disabled={idx === questions.length - 1}
                            style={{
                              background: "none",
                              border: "1px solid #e2e8f0",
                              borderRadius: "6px",
                              padding: "4px 8px",
                              cursor: idx === questions.length - 1 ? "not-allowed" : "pointer",
                              opacity: idx === questions.length - 1 ? 0.4 : 1,
                            }}
                            title="Move Down"
                          >
                            ▼
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDuplicateQuestion(q.id)}
                            style={{ background: "none", border: "1px solid #e2e8f0", borderRadius: "6px", padding: "4px 8px", cursor: "pointer" }}
                            title="Duplicate"
                          >
                            ⧉ Duplicate
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteQuestion(q.id)}
                            style={{ background: "#fee2e2", border: "none", borderRadius: "6px", padding: "4px 8px", color: "#dc2626", cursor: "pointer", fontWeight: "700" }}
                            title="Delete"
                          >
                            🗑
                          </button>
                        </div>
                      </div>

                      {/* Question Text Input */}
                      <div style={{ marginBottom: "14px" }}>
                        <textarea
                          rows={2}
                          value={q.question}
                          onChange={(e) => handleUpdateQuestion(q.id, "question", e.target.value)}
                          placeholder="What is the value of x?"
                          style={{
                            width: "100%",
                            padding: "10px 12px",
                            borderRadius: "10px",
                            border: "1px solid #cbd5e1",
                            fontSize: "14px",
                            fontWeight: "600",
                            color: "#0c211d",
                            outline: "none",
                            resize: "vertical",
                          }}
                        />
                      </div>

                      {/* Options Editor */}
                      <div style={{ marginBottom: "14px" }}>
                        <div style={{ fontSize: "12px", fontWeight: "700", color: "#64748b", marginBottom: "8px" }}>
                          Options & Correct Answer Selection (Select radio button for the correct key):
                        </div>

                        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                          {q.options.map((opt, optIdx) => (
                            <div
                              key={optIdx}
                              style={{
                                display: "flex",
                                alignItems: "center",
                                gap: "10px",
                                background: q.correctAnswer === optIdx ? "#ecfdf5" : "#ffffff",
                                padding: "6px 10px",
                                borderRadius: "8px",
                                border: q.correctAnswer === optIdx ? "1.5px solid #10b981" : "1px solid #e2e8f0",
                              }}
                            >
                              <input
                                type="radio"
                                name={`correct-${q.id}`}
                                checked={q.correctAnswer === optIdx}
                                onChange={() => handleUpdateQuestion(q.id, "correctAnswer", optIdx)}
                                style={{ width: "16px", height: "16px", accentColor: "#059669", cursor: "pointer" }}
                              />
                              <input
                                type="text"
                                value={opt}
                                disabled={q.type === "TRUE_FALSE"}
                                onChange={(e) => {
                                  const updatedOpts = [...q.options];
                                  updatedOpts[optIdx] = e.target.value;
                                  handleUpdateQuestion(q.id, "options", updatedOpts);
                                }}
                                style={{
                                  flex: 1,
                                  border: "none",
                                  background: "transparent",
                                  fontSize: "13.5px",
                                  fontWeight: q.correctAnswer === optIdx ? "700" : "500",
                                  color: "#0c211d",
                                  outline: "none",
                                }}
                              />
                              {q.correctAnswer === optIdx && (
                                <span style={{ fontSize: "11px", fontWeight: "800", color: "#059669", background: "#dcfce7", padding: "2px 8px", borderRadius: "999px" }}>
                                  ✓ Correct Answer
                                </span>
                              )}
                              {q.type === "MCQ" && q.options.length > 2 && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveOption(q.id, optIdx)}
                                  style={{ background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: "14px" }}
                                  title="Remove option"
                                >
                                  ✕
                                </button>
                              )}
                            </div>
                          ))}
                        </div>

                        {q.type === "MCQ" && q.options.length < 6 && (
                          <button
                            type="button"
                            onClick={() => handleAddOption(q.id)}
                            style={{
                              marginTop: "8px",
                              background: "none",
                              border: "1px dashed #059669",
                              color: "#059669",
                              padding: "6px 14px",
                              borderRadius: "8px",
                              fontSize: "12px",
                              fontWeight: "700",
                              cursor: "pointer",
                            }}
                          >
                            + Add Option
                          </button>
                        )}
                      </div>

                      {/* Marks & Explanation Grid */}
                      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: "14px", alignItems: "flex-start" }}>
                        <div>
                          <label style={{ display: "block", fontSize: "11.5px", fontWeight: "700", color: "#64748b", marginBottom: "4px" }}>
                            Marks
                          </label>
                          <input
                            type="number"
                            min={1}
                            max={20}
                            value={q.marks || 2}
                            onChange={(e) => handleUpdateQuestion(q.id, "marks", parseInt(e.target.value, 10) || 1)}
                            style={{
                              width: "100%",
                              padding: "8px 10px",
                              borderRadius: "8px",
                              border: "1px solid #cbd5e1",
                              fontSize: "13px",
                              fontWeight: "700",
                              outline: "none",
                            }}
                          />
                        </div>

                        <div>
                          <label style={{ display: "block", fontSize: "11.5px", fontWeight: "700", color: "#64748b", marginBottom: "4px" }}>
                            Explanation (Optional solution for student review)
                          </label>
                          <input
                            type="text"
                            value={q.explanation || ""}
                            onChange={(e) => handleUpdateQuestion(q.id, "explanation", e.target.value)}
                            placeholder="e.g. By factoring (x - 2)(x + 4) = 0..."
                            style={{
                              width: "100%",
                              padding: "8px 12px",
                              borderRadius: "8px",
                              border: "1px solid #cbd5e1",
                              fontSize: "13px",
                              outline: "none",
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add Question Button Toolbar (Section 10) */}
                <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", padding: "16px 0" }}>
                  <button
                    type="button"
                    onClick={() => handleAddQuestion("MCQ")}
                    style={{
                      padding: "10px 18px",
                      borderRadius: "10px",
                      background: "#059669",
                      color: "#ffffff",
                      fontSize: "13px",
                      fontWeight: "700",
                      border: "none",
                      cursor: "pointer",
                    }}
                  >
                    + Add MCQ Question
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAddQuestion("TRUE_FALSE")}
                    style={{
                      padding: "10px 18px",
                      borderRadius: "10px",
                      background: "#eff6ff",
                      border: "1px solid #bfdbfe",
                      color: "#1d4ed8",
                      fontSize: "13px",
                      fontWeight: "700",
                      cursor: "pointer",
                    }}
                  >
                    + Add True / False
                  </button>
                </div>
              </div>

              {/* Right Column: Settings Panel (Section 9) */}
              <div
                style={{
                  background: "#ffffff",
                  border: "1px solid #e8f0eb",
                  borderRadius: "20px",
                  padding: "24px",
                  position: "sticky",
                  top: "96px",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
                  display: "flex",
                  flexDirection: "column",
                  gap: "18px",
                }}
              >
                <h3 style={{ fontSize: "16px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                  Assessment Settings
                </h3>

                <div>
                  <label style={{ display: "block", fontSize: "12px", fontWeight: "700", color: "#64748b", marginBottom: "6px" }}>
                    Target Course
                  </label>
                  <select
                    value={quizCourseId}
                    onChange={(e) => setQuizCourseId(e.target.value)}
                    style={{
                      width: "100%",
                      padding: "9px 12px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "13px",
                      background: "#fff",
                      outline: "none",
                    }}
                  >
                    {courses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "12px", fontWeight: "700", color: "#64748b", marginBottom: "6px" }}>
                    Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={180}
                    value={quizDurationMinutes}
                    onChange={(e) => setQuizDurationMinutes(parseInt(e.target.value, 10) || 30)}
                    style={{
                      width: "100%",
                      padding: "9px 12px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "13.5px",
                      outline: "none",
                    }}
                  />
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "12px", fontWeight: "700", color: "#64748b", marginBottom: "6px" }}>
                    Allowed Attempts
                  </label>
                  <select
                    value={quizAttempts}
                    onChange={(e) => setQuizAttempts(parseInt(e.target.value, 10) || 1)}
                    style={{
                      width: "100%",
                      padding: "9px 12px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "13px",
                      background: "#fff",
                      outline: "none",
                    }}
                  >
                    <option value={1}>1 Attempt</option>
                    <option value={2}>2 Attempts</option>
                    <option value={3}>3 Attempts</option>
                    <option value={999}>Unlimited</option>
                  </select>
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "12px", fontWeight: "700", color: "#64748b", marginBottom: "6px" }}>
                    Passing Percentage
                  </label>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <input
                      type="number"
                      min={10}
                      max={100}
                      value={quizPassingScore}
                      onChange={(e) => setQuizPassingScore(parseInt(e.target.value, 10) || 60)}
                      style={{
                        flex: 1,
                        padding: "9px 12px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "13.5px",
                        outline: "none",
                      }}
                    />
                    <span style={{ fontWeight: "700", color: "#64748b" }}>%</span>
                  </div>
                </div>

                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: "8px", borderTop: "1px solid #f1f5f9" }}>
                  <span style={{ fontSize: "13px", fontWeight: "600", color: "#0c211d" }}>Shuffle Question Order</span>
                  <input
                    type="checkbox"
                    checked={shuffleQuestions}
                    onChange={(e) => setShuffleQuestions(e.target.checked)}
                    style={{ width: "18px", height: "18px", accentColor: "#059669", cursor: "pointer" }}
                  />
                </div>

                <div style={{ background: "#f8faf9", padding: "14px", borderRadius: "12px", fontSize: "12px", color: "#64748b" }}>
                  <div>Total Questions: <strong>{questions.length}</strong></div>
                  <div style={{ marginTop: "4px" }}>
                    Total Marks: <strong>{questions.reduce((acc, q) => acc + (q.marks || 2), 0)}</strong>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ==========================================================================
            MODE 3: STUDENT-STYLE QUIZ PREVIEW (Section 12)
            ========================================================================== */}
        {studioMode === "preview" && (
          <div style={{ maxWidth: "780px", margin: "0 auto" }}>
            {/* Preview Navigation Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
              <button
                type="button"
                onClick={() => setStudioMode("builder")}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "#059669",
                  fontSize: "13.5px",
                  fontWeight: "700",
                  cursor: "pointer",
                }}
              >
                ← Return to Builder
              </button>

              <span
                style={{
                  background: "#eff6ff",
                  color: "#1d4ed8",
                  padding: "4px 12px",
                  borderRadius: "999px",
                  fontSize: "12px",
                  fontWeight: "800",
                  letterSpacing: "0.05em",
                }}
              >
                STUDENT EXPERIENCE SIMULATOR
              </span>
            </div>

            {/* Quiz Preview Card */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e8f0eb",
                borderRadius: "24px",
                padding: "36px",
                boxShadow: "0 10px 30px rgba(12, 33, 29, 0.05)",
              }}
            >
              {previewSubmitted ? (
                <div style={{ textAlign: "center", padding: "20px 0" }}>
                  <div style={{ fontSize: "44px", marginBottom: "12px" }}>
                    {previewScoreResult.passed ? "🏆" : "📘"}
                  </div>
                  <h2 style={{ fontSize: "22px", fontWeight: "800", color: "#0c211d", margin: "0 0 8px 0" }}>
                    {previewScoreResult.passed ? "Test Passed Successfully!" : "Test Completed"}
                  </h2>
                  <p style={{ fontSize: "14px", color: "#64748b", margin: "0 0 20px 0" }}>
                    Simulation score: {previewScoreResult.score} / {previewScoreResult.max} marks ({previewScoreResult.pct}%)
                  </p>
                  <div style={{ display: "inline-block", padding: "6px 18px", borderRadius: "999px", background: previewScoreResult.passed ? "#dcfce7" : "#fee2e2", color: previewScoreResult.passed ? "#166534" : "#991b1b", fontWeight: "800", fontSize: "13px", marginBottom: "24px" }}>
                    Passing Requirement: {quizPassingScore}%
                  </div>
                  <div>
                    <button
                      type="button"
                      onClick={() => {
                        setPreviewSubmitted(false);
                        setPreviewQuestionIndex(0);
                        setPreviewSelectedAnswers({});
                      }}
                      style={{
                        padding: "10px 20px",
                        borderRadius: "10px",
                        background: "#059669",
                        color: "#fff",
                        fontWeight: "700",
                        fontSize: "13px",
                        border: "none",
                        cursor: "pointer",
                      }}
                    >
                      Retry Simulation
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  {/* Student View Header */}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingBottom: "16px", borderBottom: "1px solid #f1f5f9", marginBottom: "24px" }}>
                    <div>
                      <h3 style={{ fontSize: "18px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                        {quizTitle}
                      </h3>
                      <span style={{ fontSize: "12.5px", color: "#64748b" }}>
                        Question {previewQuestionIndex + 1} of {questions.length}
                      </span>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", background: "#f8faf9", padding: "6px 12px", borderRadius: "999px", fontSize: "12px", fontWeight: "700", color: "#0c211d" }}>
                      ⏱️ {quizDurationMinutes}:00
                    </div>
                  </div>

                  {/* Question Prompt */}
                  <div style={{ fontSize: "17px", fontWeight: "700", color: "#0c211d", marginBottom: "24px", lineHeight: "1.4" }}>
                    {questions[previewQuestionIndex]?.question}
                  </div>

                  {/* Options List */}
                  <div style={{ display: "flex", flexDirection: "column", gap: "10px", marginBottom: "32px" }}>
                    {questions[previewQuestionIndex]?.options.map((opt, oIdx) => {
                      const isSelected = previewSelectedAnswers[previewQuestionIndex] === oIdx;
                      return (
                        <div
                          key={oIdx}
                          onClick={() => {
                            setPreviewSelectedAnswers({
                              ...previewSelectedAnswers,
                              [previewQuestionIndex]: oIdx,
                            });
                          }}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "12px",
                            padding: "14px 18px",
                            borderRadius: "12px",
                            border: isSelected ? "2px solid #059669" : "1px solid #e2e8f0",
                            background: isSelected ? "#ecfdf5" : "#ffffff",
                            cursor: "pointer",
                            transition: "all 0.15s ease",
                          }}
                        >
                          <div
                            style={{
                              width: "20px",
                              height: "20px",
                              borderRadius: "50%",
                              border: isSelected ? "6px solid #059669" : "2px solid #cbd5e1",
                              background: "#fff",
                            }}
                          />
                          <span style={{ fontSize: "14.5px", fontWeight: isSelected ? "700" : "500", color: "#0c211d" }}>
                            {opt}
                          </span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Navigation Buttons (Section 12) */}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <button
                      type="button"
                      disabled={previewQuestionIndex === 0}
                      onClick={() => setPreviewQuestionIndex((prev) => Math.max(0, prev - 1))}
                      style={{
                        padding: "10px 20px",
                        borderRadius: "10px",
                        background: "#f1f5f9",
                        border: "none",
                        color: previewQuestionIndex === 0 ? "#94a3b8" : "#0c211d",
                        fontWeight: "700",
                        fontSize: "13.5px",
                        cursor: previewQuestionIndex === 0 ? "not-allowed" : "pointer",
                      }}
                    >
                      Previous
                    </button>

                    {previewQuestionIndex < questions.length - 1 ? (
                      <button
                        type="button"
                        onClick={() => setPreviewQuestionIndex((prev) => Math.min(questions.length - 1, prev + 1))}
                        style={{
                          padding: "10px 24px",
                          borderRadius: "10px",
                          background: "#059669",
                          color: "#ffffff",
                          fontWeight: "700",
                          fontSize: "13.5px",
                          border: "none",
                          cursor: "pointer",
                        }}
                      >
                        Next
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setPreviewSubmitted(true)}
                        style={{
                          padding: "10px 24px",
                          borderRadius: "10px",
                          background: "#2563eb",
                          color: "#ffffff",
                          fontWeight: "700",
                          fontSize: "13.5px",
                          border: "none",
                          cursor: "pointer",
                        }}
                      >
                        Submit Test Preview
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </TrainerShell>
  );
}
