"use client";

import React, { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import TrainerShell from "@/components/trainer/TrainerShell";
import { useTrainer } from "@/lib/services/TrainerContext";

export default function TrainerLiveStudioPage() {
  const searchParams = useSearchParams();
  const initialTab = searchParams?.get("tab") || (searchParams?.get("action") === "schedule" ? "schedule" : "sessions");

  const [activeViewTab, setActiveViewTab] = useState(initialTab); // 'sessions' | 'schedule' | 'calendar'
  const [searchQuery, setSearchQuery] = useState("");
  const [calendarViewMode, setCalendarViewMode] = useState("week"); // 'today' | 'week' | 'upcoming' | 'completed'
  const [selectedSessionForModal, setSelectedSessionForModal] = useState(null);

  // Live on-air controls state
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCamOn, setIsCamOn] = useState(true);
  const [isSharingScreen, setIsSharingScreen] = useState(false);
  const [isLiveBroadcastActive, setIsLiveBroadcastActive] = useState(false);
  const [studioAttendeeTab, setStudioAttendeeTab] = useState("attendees");

  // Form State for Session Scheduler (Section 7)
  const { courses, liveClasses, scheduleLiveClass, trainees } = useTrainer();

  const [formTitle, setFormTitle] = useState("Algebra — Quadratic Equations");
  const [formDescription, setFormDescription] = useState("Comprehensive lecture on discriminant derivation, nature of roots, and real-world projectile trajectories.");
  const [formCourseId, setFormCourseId] = useState(courses[0]?.id || "course-math-10");
  const [formBatch, setFormBatch] = useState("Class 10 — Section A");
  const [formDate, setFormDate] = useState("2026-09-08");
  const [formStartTime, setFormStartTime] = useState("16:00");
  const [formEndTime, setFormEndTime] = useState("17:00");
  const [formMeetingUrl, setFormMeetingUrl] = useState("https://meet.sarthi.gov.in/live-math-alg");
  const [formSessionType, setFormSessionType] = useState("Live Class");
  const [formMaxStudents, setFormMaxStudents] = useState(32);
  const [isSubmittingSchedule, setIsSubmittingSchedule] = useState(false);
  const [scheduleSuccessMsg, setScheduleSuccessMsg] = useState("");

  // Sync tab with search params
  useEffect(() => {
    const tab = searchParams?.get("tab");
    const action = searchParams?.get("action");
    if (tab === "calendar") setActiveViewTab("calendar");
    else if (action === "schedule") setActiveViewTab("schedule");
  }, [searchParams]);

  // Selected course object
  const selectedCourse = useMemo(() => {
    return courses.find((c) => c.id === formCourseId) || courses[0] || { title: "Mathematics — Class 10" };
  }, [courses, formCourseId]);

  // Handle schedule submission
  const handleScheduleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmittingSchedule(true);
    setScheduleSuccessMsg("");

    const formatTime12h = (time24) => {
      if (!time24) return "4:00 PM";
      const [h, m] = time24.split(":");
      const hour = parseInt(h, 10);
      const ampm = hour >= 12 ? "PM" : "AM";
      const h12 = hour % 12 || 12;
      return `${h12}:${m} ${ampm}`;
    };

    const formattedRange = `${formatTime12h(formStartTime)} – ${formatTime12h(formEndTime)}`;

    await scheduleLiveClass({
      title: formTitle,
      description: formDescription,
      courseId: formCourseId,
      courseTitle: selectedCourse.title,
      class: formBatch,
      batch: formBatch,
      date: formDate,
      time: formattedRange,
      startTime: formStartTime,
      endTime: formEndTime,
      meetingUrl: formMeetingUrl,
      sessionType: formSessionType,
      maxStudents: Number(formMaxStudents) || 32,
    });

    setIsSubmittingSchedule(false);
    setScheduleSuccessMsg("✓ Session scheduled successfully!");
    setTimeout(() => {
      setActiveViewTab("sessions");
    }, 1200);
  };

  // Connected attendees in studio
  const connectedAttendees = [
    { id: "std-1", name: "Aarav Sharma", division: "Class 10 A", mic: false, handRaised: true, avatar: "/images/student-img-1.jpg" },
    { id: "std-2", name: "Ananya Singh", division: "Class 10 A", mic: false, handRaised: false, avatar: "/images/student-img-2.jpg" },
    { id: "std-3", name: "Rahul Verma", division: "Class 10 A", mic: false, handRaised: false, avatar: "/images/student-img-3.jpg" },
    { id: "std-4", name: "Priya Gupta", division: "Class 10 A", mic: true, handRaised: false, avatar: "/images/student-img-2.jpg" },
    { id: "std-5", name: "Vikram Malhotra", division: "Class 10 A", mic: false, handRaised: true, avatar: "/images/student-img-1.jpg" },
  ];

  return (
    <TrainerShell searchQuery={searchQuery} setSearchQuery={setSearchQuery} placeholder="Search sessions, calendar, or student attendees...">
      <div style={{ padding: "28px 36px 64px 36px", maxWidth: "1360px", margin: "0 auto", width: "100%" }}>
        {/* Page Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "24px", flexWrap: "wrap", gap: "16px" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
              <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#ef4444" }} />
              <span style={{ fontSize: "11px", fontWeight: "800", color: "#065f46", letterSpacing: "0.12em", textTransform: "uppercase" }}>
                SYNCHRONOUS TEACHING STUDIO
              </span>
            </div>
            <h1 style={{ fontSize: "30px", fontWeight: "800", color: "#0a2920", margin: "0 0 6px 0", letterSpacing: "-0.5px" }}>
              Live Classes & Scheduler
            </h1>
            <p style={{ fontSize: "14px", color: "#64748b", margin: 0 }}>
              Broadcast synchronous classes, schedule new batch sessions with live preview, and review your weekly teaching timetable.
            </p>
          </div>

          {/* Tab Switcher Pills */}
          <div
            style={{
              display: "inline-flex",
              background: "#f1f5f9",
              padding: "4px",
              borderRadius: "14px",
              gap: "4px",
            }}
          >
            <button
              type="button"
              onClick={() => setActiveViewTab("sessions")}
              style={{
                border: "none",
                padding: "8px 16px",
                borderRadius: "10px",
                fontSize: "13px",
                fontWeight: "700",
                cursor: "pointer",
                background: activeViewTab === "sessions" ? "#ffffff" : "transparent",
                color: activeViewTab === "sessions" ? "#0c211d" : "#64748b",
                boxShadow: activeViewTab === "sessions" ? "0 2px 6px rgba(0,0,0,0.06)" : "none",
                transition: "all 0.15s ease",
              }}
            >
              📹 Live Sessions
            </button>

            <button
              type="button"
              onClick={() => setActiveViewTab("schedule")}
              style={{
                border: "none",
                padding: "8px 16px",
                borderRadius: "10px",
                fontSize: "13px",
                fontWeight: "700",
                cursor: "pointer",
                background: activeViewTab === "schedule" ? "#ffffff" : "transparent",
                color: activeViewTab === "schedule" ? "#0c211d" : "#64748b",
                boxShadow: activeViewTab === "schedule" ? "0 2px 6px rgba(0,0,0,0.06)" : "none",
                transition: "all 0.15s ease",
              }}
            >
              ➕ Schedule Session
            </button>

            <button
              type="button"
              onClick={() => setActiveViewTab("calendar")}
              style={{
                border: "none",
                padding: "8px 16px",
                borderRadius: "10px",
                fontSize: "13px",
                fontWeight: "700",
                cursor: "pointer",
                background: activeViewTab === "calendar" ? "#ffffff" : "transparent",
                color: activeViewTab === "calendar" ? "#0c211d" : "#64748b",
                boxShadow: activeViewTab === "calendar" ? "0 2px 6px rgba(0,0,0,0.06)" : "none",
                transition: "all 0.15s ease",
              }}
            >
              📅 Calendar View
            </button>
          </div>
        </div>

        {/* ==========================================================================
            TAB 1: LIVE SESSIONS LIST & ON-AIR BROADCAST CONTROL
            ========================================================================== */}
        {activeViewTab === "sessions" && (
          <div>
            {/* Top KPI Cards */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                gap: "14px",
                marginBottom: "28px",
              }}
            >
              <div className="edtech-kpi-card">
                <div className="edtech-kpi-header">
                  <div className="edtech-kpi-icon" style={{ background: isLiveBroadcastActive ? "#fee2e2" : "#f1f5f9", color: isLiveBroadcastActive ? "#dc2626" : "#64748b" }}>
                    <span style={{ width: "10px", height: "10px", borderRadius: "50%", background: isLiveBroadcastActive ? "#dc2626" : "#94a3b8" }} />
                  </div>
                  <span className="edtech-trend-badge" style={{ background: isLiveBroadcastActive ? "#fee2e2" : "#f1f5f9", color: isLiveBroadcastActive ? "#dc2626" : "#64748b" }}>
                    {isLiveBroadcastActive ? "ON-AIR" : "STANDBY"}
                  </span>
                </div>
                <div>
                  <div className="edtech-kpi-val" style={{ color: isLiveBroadcastActive ? "#dc2626" : "#0c211d" }}>
                    {isLiveBroadcastActive ? "Broadcasting" : "Ready"}
                  </div>
                  <div className="edtech-kpi-label">Studio State</div>
                </div>
              </div>

              <div className="edtech-kpi-card">
                <div className="edtech-kpi-header">
                  <div className="edtech-kpi-icon" style={{ background: "#ecfdf5", color: "#059669" }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="23 7 16 12 23 17 23 7"></polygon><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect></svg>
                  </div>
                  <span className="edtech-trend-badge positive">Today: 2</span>
                </div>
                <div>
                  <div className="edtech-kpi-val">{liveClasses.length}</div>
                  <div className="edtech-kpi-label">Scheduled Classes</div>
                </div>
              </div>

              <div className="edtech-kpi-card">
                <div className="edtech-kpi-header">
                  <div className="edtech-kpi-icon" style={{ background: "#eff6ff", color: "#2563eb" }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                  </div>
                  <span className="edtech-trend-badge positive">92% Rate</span>
                </div>
                <div>
                  <div className="edtech-kpi-val">{liveClasses.reduce((acc, l) => acc + (l.registeredCount || 32), 0)}</div>
                  <div className="edtech-kpi-label">Total Trainees Enrolled</div>
                </div>
              </div>
            </div>

            {/* Live Studio Broadcaster Box */}
            <div
              style={{
                background: "#031813",
                borderRadius: "20px",
                border: "1px solid rgba(16, 185, 129, 0.2)",
                padding: "24px",
                color: "#ffffff",
                marginBottom: "32px",
                boxShadow: "0 20px 40px -10px rgba(0, 0, 0, 0.3)",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px", flexWrap: "wrap", gap: "12px" }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }}>
                    <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: isLiveBroadcastActive ? "#ef4444" : "#10b981", animation: isLiveBroadcastActive ? "pulse 1s infinite" : "none" }} />
                    <span style={{ fontSize: "11px", fontWeight: "800", color: "#a7f3d0", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                      {isLiveBroadcastActive ? "LIVE BROADCAST IN PROGRESS" : "FACULTY DESK STUDIO"}
                    </span>
                  </div>
                  <h2 style={{ fontSize: "20px", fontWeight: "800", margin: 0 }}>
                    Mathematics — Algebra • Quadratic Equations Masterclass
                  </h2>
                  <p style={{ fontSize: "13px", color: "#94a3b8", margin: "4px 0 0 0" }}>
                    Class 10 — Section A • 32 Students In Virtual Waiting Room
                  </p>
                </div>

                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  <button
                    type="button"
                    onClick={() => setIsLiveBroadcastActive((prev) => !prev)}
                    style={{
                      padding: "10px 20px",
                      borderRadius: "12px",
                      background: isLiveBroadcastActive ? "#dc2626" : "linear-gradient(135deg, #059669 0%, #10b981 100%)",
                      color: "#ffffff",
                      fontSize: "13.5px",
                      fontWeight: "700",
                      border: "none",
                      cursor: "pointer",
                      boxShadow: isLiveBroadcastActive ? "0 4px 14px rgba(220, 38, 38, 0.4)" : "0 4px 14px rgba(5, 150, 105, 0.3)",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "8px",
                    }}
                  >
                    <span>{isLiveBroadcastActive ? "⏹ End Class" : "🔴 Start Live Class"}</span>
                  </button>
                </div>
              </div>

              {/* Studio Video Simulation & Controls */}
              <div
                style={{
                  background: "#010e0b",
                  borderRadius: "16px",
                  height: "260px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  position: "relative",
                  border: "1px solid rgba(255, 255, 255, 0.08)",
                }}
              >
                <div style={{ textAlign: "center" }}>
                  <div style={{ width: "64px", height: "64px", borderRadius: "50%", background: "rgba(16, 185, 129, 0.15)", border: "2px solid #10b981", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px auto" }}>
                    <span style={{ fontSize: "28px" }}>👨‍🏫</span>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: "700", color: "#ffffff" }}>{trainer.name}</div>
                  <div style={{ fontSize: "12px", color: "#a7f3d0" }}>Broadcasting Camera: {isCamOn ? "1080p HD Active" : "Camera Off"}</div>
                </div>

                {/* Bottom Media Controls Bar */}
                <div
                  style={{
                    position: "absolute",
                    bottom: "16px",
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    background: "rgba(0, 0, 0, 0.65)",
                    padding: "8px 16px",
                    borderRadius: "999px",
                    backdropFilter: "blur(8px)",
                  }}
                >
                  <button
                    type="button"
                    onClick={() => setIsMicOn((p) => !p)}
                    style={{
                      background: isMicOn ? "#059669" : "#dc2626",
                      color: "#fff",
                      border: "none",
                      width: "36px",
                      height: "36px",
                      borderRadius: "50%",
                      cursor: "pointer",
                    }}
                    title={isMicOn ? "Mute Mic" : "Unmute Mic"}
                  >
                    {isMicOn ? "🎙️" : "🔇"}
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsCamOn((p) => !p)}
                    style={{
                      background: isCamOn ? "#059669" : "#dc2626",
                      color: "#fff",
                      border: "none",
                      width: "36px",
                      height: "36px",
                      borderRadius: "50%",
                      cursor: "pointer",
                    }}
                    title={isCamOn ? "Turn Camera Off" : "Turn Camera On"}
                  >
                    {isCamOn ? "📹" : "🚫"}
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsSharingScreen((p) => !p)}
                    style={{
                      background: isSharingScreen ? "#2563eb" : "rgba(255, 255, 255, 0.15)",
                      color: "#fff",
                      border: "none",
                      padding: "6px 14px",
                      borderRadius: "999px",
                      cursor: "pointer",
                      fontSize: "12px",
                      fontWeight: "700",
                    }}
                  >
                    {isSharingScreen ? "Stop Sharing" : "🖥️ Share Screen"}
                  </button>
                </div>
              </div>
            </div>

            {/* Sessions Cards Section */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h3 style={{ fontSize: "18px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                All Scheduled Sessions
              </h3>
              <button
                type="button"
                onClick={() => setActiveViewTab("schedule")}
                className="db-btn-primary"
                style={{
                  padding: "8px 16px",
                  borderRadius: "10px",
                  background: "#059669",
                  color: "#fff",
                  fontSize: "13px",
                  fontWeight: "700",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                + Schedule Session
              </button>
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
                gap: "16px",
              }}
            >
              {liveClasses.map((session, idx) => (
                <div key={session.id} className="session-card">
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div>
                      <div style={{ fontSize: "11px", fontWeight: "800", color: "#059669", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "4px" }}>
                        {session.courseName || "Class 10 Mathematics"}
                      </div>
                      <h4 style={{ fontSize: "16px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                        {session.title}
                      </h4>
                    </div>

                    <span className={idx === 0 ? "status-badge-live" : "status-badge-upcoming"}>
                      {idx === 0 ? "🔴 LIVE" : "UPCOMING"}
                    </span>
                  </div>

                  <div style={{ background: "#f8faf9", padding: "12px", borderRadius: "12px", display: "flex", flexDirection: "column", gap: "6px" }}>
                    <div style={{ fontSize: "13px", color: "#0c211d", fontWeight: "700" }}>
                      📅 {session.date === "2026-09-08" ? "Today" : session.date} • {session.time || "4:00 PM – 5:00 PM"}
                    </div>
                    <div style={{ fontSize: "12.5px", color: "#64748b" }}>
                      👥 {session.class || session.batch || "Class 10 — Section A"} • {session.registeredCount || 32} students
                    </div>
                    <div style={{ fontSize: "12px", color: "#94a3b8" }}>
                      🏷️ {session.sessionType || "Live Class"}
                    </div>
                  </div>

                  <div style={{ display: "flex", gap: "8px", marginTop: "auto" }}>
                    <a
                      href={session.meetingUrl || "https://meet.sarthi.gov.in"}
                      target="_blank"
                      rel="noreferrer"
                      style={{
                        flex: 1,
                        padding: "9px 12px",
                        borderRadius: "10px",
                        background: idx === 0 ? "#dc2626" : "#059669",
                        color: "#fff",
                        fontSize: "12.5px",
                        fontWeight: "700",
                        textAlign: "center",
                        textDecoration: "none",
                      }}
                    >
                      {idx === 0 ? "🔴 Join Session" : "Join Session"}
                    </a>

                    <button
                      type="button"
                      onClick={() => setSelectedSessionForModal(session)}
                      style={{
                        padding: "9px 14px",
                        borderRadius: "10px",
                        background: "#ffffff",
                        border: "1px solid #e2e8f0",
                        color: "#0c211d",
                        fontSize: "12.5px",
                        fontWeight: "700",
                        cursor: "pointer",
                      }}
                    >
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==========================================================================
            TAB 2: SESSION SCHEDULER WITH REAL-TIME PREVIEW (Section 7)
            ========================================================================== */}
        {activeViewTab === "schedule" && (
          <div>
            <div style={{ marginBottom: "20px" }}>
              <button
                type="button"
                onClick={() => setActiveViewTab("sessions")}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "#059669",
                  fontSize: "13px",
                  fontWeight: "700",
                  cursor: "pointer",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "6px",
                  padding: 0,
                  marginBottom: "8px",
                }}
              >
                ← Back to Sessions
              </button>
              <h2 style={{ fontSize: "24px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                Schedule Live Session
              </h2>
              <p style={{ fontSize: "14px", color: "#64748b", margin: "4px 0 0 0" }}>
                Fill out the teaching specifications below. The student invitation card on the right updates in real-time.
              </p>
            </div>

            {scheduleSuccessMsg && (
              <div
                style={{
                  padding: "12px 16px",
                  background: "#dcfce7",
                  border: "1px solid #86efac",
                  borderRadius: "12px",
                  color: "#166534",
                  fontWeight: "700",
                  marginBottom: "20px",
                }}
              >
                {scheduleSuccessMsg}
              </div>
            )}

            {/* 2-Column Layout: Form (Left) & Real-time Live Preview (Right) */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 380px",
                gap: "28px",
                alignItems: "flex-start",
              }}
            >
              {/* Left Side: Scheduling Form */}
              <form
                onSubmit={handleScheduleSubmit}
                style={{
                  background: "#ffffff",
                  border: "1px solid var(--sarthi-border, #e8f0eb)",
                  borderRadius: "20px",
                  padding: "28px",
                  display: "flex",
                  flexDirection: "column",
                  gap: "18px",
                  boxShadow: "0 1px 3px rgba(0, 0, 0, 0.02)",
                }}
              >
                <div>
                  <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                    Session Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    placeholder="e.g. Algebra — Quadratic Equations"
                    style={{
                      width: "100%",
                      padding: "10px 14px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  />
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                    Description
                  </label>
                  <textarea
                    rows={3}
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    placeholder="Provide context, topics covered, and prerequisites..."
                    style={{
                      width: "100%",
                      padding: "10px 14px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "13.5px",
                      outline: "none",
                      resize: "vertical",
                    }}
                  />
                </div>

                {/* Course & Batch */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                      Course *
                    </label>
                    <select
                      value={formCourseId}
                      onChange={(e) => setFormCourseId(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "10px 12px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "13.5px",
                        background: "#fff",
                        outline: "none",
                      }}
                    >
                      {courses.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                      Class / Batch *
                    </label>
                    <input
                      type="text"
                      required
                      value={formBatch}
                      onChange={(e) => setFormBatch(e.target.value)}
                      placeholder="e.g. Class 10 — Section A"
                      style={{
                        width: "100%",
                        padding: "10px 14px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "13.5px",
                        outline: "none",
                      }}
                    />
                  </div>
                </div>

                {/* Date & Times */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                      Date *
                    </label>
                    <input
                      type="date"
                      required
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "10px 10px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "13px",
                        outline: "none",
                      }}
                    />
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                      Start Time *
                    </label>
                    <input
                      type="time"
                      required
                      value={formStartTime}
                      onChange={(e) => setFormStartTime(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "10px 10px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "13px",
                        outline: "none",
                      }}
                    />
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                      End Time *
                    </label>
                    <input
                      type="time"
                      required
                      value={formEndTime}
                      onChange={(e) => setFormEndTime(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "10px 10px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "13px",
                        outline: "none",
                      }}
                    />
                  </div>
                </div>

                {/* Session Type & Capacity */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                  <div>
                    <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                      Session Type
                    </label>
                    <select
                      value={formSessionType}
                      onChange={(e) => setFormSessionType(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "10px 12px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "13.5px",
                        background: "#fff",
                        outline: "none",
                      }}
                    >
                      <option value="Live Class">Live Class</option>
                      <option value="Lab Practical">Lab Practical</option>
                      <option value="Interactive Seminar">Interactive Seminar</option>
                      <option value="Doubt Clearing Session">Doubt Clearing Session</option>
                    </select>
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                      Maximum Students
                    </label>
                    <input
                      type="number"
                      min={5}
                      max={200}
                      value={formMaxStudents}
                      onChange={(e) => setFormMaxStudents(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "10px 14px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "13.5px",
                        outline: "none",
                      }}
                    />
                  </div>
                </div>

                {/* Meeting URL */}
                <div>
                  <label style={{ display: "block", fontSize: "13px", fontWeight: "700", color: "#0c211d", marginBottom: "6px" }}>
                    Meeting URL
                  </label>
                  <input
                    type="url"
                    value={formMeetingUrl}
                    onChange={(e) => setFormMeetingUrl(e.target.value)}
                    placeholder="https://meet.sarthi.gov.in/..."
                    style={{
                      width: "100%",
                      padding: "10px 14px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "13.5px",
                      outline: "none",
                    }}
                  />
                </div>

                {/* Submit Action Button */}
                <button
                  type="submit"
                  disabled={isSubmittingSchedule}
                  className="db-btn-primary"
                  style={{
                    marginTop: "8px",
                    padding: "12px 24px",
                    borderRadius: "12px",
                    background: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
                    color: "#ffffff",
                    fontSize: "14px",
                    fontWeight: "700",
                    border: "none",
                    cursor: "pointer",
                    boxShadow: "0 4px 12px rgba(5, 150, 105, 0.25)",
                  }}
                >
                  {isSubmittingSchedule ? "Scheduling Session..." : "Schedule Live Session"}
                </button>
              </form>

              {/* Right Side: Real-time Session Preview (Section 7) */}
              <div className="session-live-preview-box">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
                  <span
                    style={{
                      background: "rgba(16, 185, 129, 0.2)",
                      border: "1px solid rgba(16, 185, 129, 0.4)",
                      color: "#6ee7b7",
                      fontSize: "11px",
                      fontWeight: "800",
                      padding: "3px 10px",
                      borderRadius: "999px",
                      letterSpacing: "0.08em",
                      textTransform: "uppercase",
                    }}
                  >
                    REAL-TIME PREVIEW
                  </span>
                  <span style={{ fontSize: "11.5px", color: "#94a3b8" }}>Student View</span>
                </div>

                <div style={{ display: "inline-block", background: "#ef4444", color: "#ffffff", fontSize: "10.5px", fontWeight: "800", padding: "2px 8px", borderRadius: "6px", marginBottom: "12px" }}>
                  LIVE CLASS
                </div>

                <h3 style={{ fontSize: "18px", fontWeight: "800", color: "#ffffff", margin: "0 0 10px 0", lineHeight: "1.3" }}>
                  {formTitle || "Algebra — Quadratic Equations"}
                </h3>

                <p style={{ fontSize: "12.5px", color: "#94a3b8", margin: "0 0 16px 0", lineHeight: "1.4" }}>
                  {formDescription || "No description provided yet."}
                </p>

                <div style={{ background: "rgba(255, 255, 255, 0.05)", border: "1px solid rgba(255, 255, 255, 0.1)", borderRadius: "12px", padding: "12px 14px", display: "flex", flexDirection: "column", gap: "8px", marginBottom: "18px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "13px", color: "#e2e8f0" }}>
                    <span>📅</span>
                    <span style={{ fontWeight: "700" }}>{formDate === "2026-09-08" ? "Today" : formDate}</span>
                    <span>•</span>
                    <span style={{ color: "#a7f3d0", fontWeight: "700" }}>
                      {formStartTime} – {formEndTime}
                    </span>
                  </div>

                  <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "12.5px", color: "#94a3b8" }}>
                    <span>🎓</span>
                    <span>{formBatch || "Class 10"} • {selectedCourse.title}</span>
                  </div>

                  <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "12.5px", color: "#94a3b8" }}>
                    <span>👥</span>
                    <span>Capacity: {formMaxStudents} students max</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleScheduleSubmit}
                  style={{
                    width: "100%",
                    padding: "10px 16px",
                    borderRadius: "10px",
                    background: "#10b981",
                    color: "#031813",
                    fontSize: "13px",
                    fontWeight: "800",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Schedule Session
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ==========================================================================
            TAB 3: CALENDAR TIMETABLE VIEW (Section 8)
            ========================================================================== */}
        {activeViewTab === "calendar" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px", flexWrap: "wrap", gap: "12px" }}>
              <div>
                <h2 style={{ fontSize: "20px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                  Weekly Teaching Timetable
                </h2>
                <span style={{ fontSize: "13px", color: "#64748b" }}>Interactive hourly time-blocks for Class 10 and laboratory batches</span>
              </div>

              {/* Filter controls */}
              <div style={{ display: "flex", gap: "6px" }}>
                {["today", "week", "upcoming", "completed"].map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setCalendarViewMode(mode)}
                    style={{
                      border: "none",
                      padding: "6px 14px",
                      borderRadius: "8px",
                      fontSize: "12.5px",
                      fontWeight: "700",
                      cursor: "pointer",
                      background: calendarViewMode === mode ? "#059669" : "#f1f5f9",
                      color: calendarViewMode === mode ? "#ffffff" : "#475569",
                      textTransform: "capitalize",
                    }}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            {/* Timetable Grid */}
            <div className="calendar-time-grid">
              {/* Header row */}
              <div style={{ background: "#f8faf9", padding: "12px 8px", fontWeight: "800", fontSize: "11.5px", color: "#64748b", textAlign: "center" }}>
                TIME
              </div>
              {["MON", "TUE", "WED", "THU", "FRI"].map((day) => (
                <div key={day} style={{ background: "#f8faf9", padding: "12px 8px", fontWeight: "800", fontSize: "12px", color: "#0c211d", textAlign: "center" }}>
                  {day}
                </div>
              ))}

              {/* 10:00 AM Row */}
              <div style={{ background: "#f8faf9", padding: "12px 8px", fontSize: "12px", fontWeight: "700", color: "#64748b", textAlign: "center" }}>
                10 AM
              </div>
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell">
                <div
                  className="calendar-session-pill"
                  onClick={() => setSelectedSessionForModal({ title: "Mathematics — Trigonometry", time: "10:00 AM – 11:00 AM", class: "Class 10 A" })}
                >
                  📐 Mathematics — Trig
                </div>
              </div>
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell" />

              {/* 12:00 PM Row */}
              <div style={{ background: "#f8faf9", padding: "12px 8px", fontSize: "12px", fontWeight: "700", color: "#64748b", textAlign: "center" }}>
                12 PM
              </div>
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell">
                <div
                  className="calendar-session-pill"
                  onClick={() => setSelectedSessionForModal({ title: "Physics — Mechanics Lab", time: "12:00 PM – 1:30 PM", class: "Class 10 B" })}
                >
                  ⚡ Physics — Mechanics
                </div>
              </div>
              <div className="calendar-grid-cell" />

              {/* 2:00 PM Row */}
              <div style={{ background: "#f8faf9", padding: "12px 8px", fontSize: "12px", fontWeight: "700", color: "#64748b", textAlign: "center" }}>
                2 PM
              </div>
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell">
                <div
                  className="calendar-session-pill"
                  onClick={() => setSelectedSessionForModal({ title: "Chemistry — Organic Bonds", time: "2:00 PM – 3:00 PM", class: "Class 10 A" })}
                >
                  🧪 Chemistry
                </div>
              </div>
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell" />

              {/* 4:00 PM Row */}
              <div style={{ background: "#f8faf9", padding: "12px 8px", fontSize: "12px", fontWeight: "700", color: "#64748b", textAlign: "center" }}>
                4 PM
              </div>
              <div className="calendar-grid-cell">
                <div
                  className="calendar-session-pill"
                  style={{ background: "#fee2e2", borderLeftColor: "#dc2626", color: "#991b1b" }}
                  onClick={() => setSelectedSessionForModal({ title: "Algebra — Quadratic Equations", time: "4:00 PM – 5:00 PM", class: "Class 10 A" })}
                >
                  🔴 Algebra (Live Class)
                </div>
              </div>
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell" />
              <div className="calendar-grid-cell">
                <div
                  className="calendar-session-pill"
                  onClick={() => setSelectedSessionForModal({ title: "Doubt Clearing Session", time: "4:00 PM – 5:00 PM", class: "Class 10 All" })}
                >
                  💡 Doubt Clearing
                </div>
              </div>
              <div className="calendar-grid-cell" />
            </div>
          </div>
        )}

        {/* Modal for Calendar Session Details */}
        {selectedSessionForModal && (
          <div
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(12, 33, 29, 0.4)",
              backdropFilter: "blur(6px)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 1000,
              padding: "20px",
            }}
            onClick={() => setSelectedSessionForModal(null)}
          >
            <div
              style={{
                background: "#ffffff",
                borderRadius: "20px",
                padding: "28px",
                width: "100%",
                maxWidth: "460px",
                boxShadow: "0 25px 50px -12px rgba(0,0,0,0.25)",
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "16px" }}>
                <div>
                  <span style={{ fontSize: "11px", fontWeight: "800", color: "#059669", textTransform: "uppercase" }}>
                    Session Details
                  </span>
                  <h3 style={{ fontSize: "18px", fontWeight: "800", color: "#0c211d", margin: "4px 0 0 0" }}>
                    {selectedSessionForModal.title}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedSessionForModal(null)}
                  style={{ background: "none", border: "none", fontSize: "18px", cursor: "pointer", color: "#94a3b8" }}
                >
                  ✕
                </button>
              </div>

              <div style={{ background: "#f8faf9", padding: "14px", borderRadius: "12px", display: "flex", flexDirection: "column", gap: "8px", marginBottom: "20px" }}>
                <div style={{ fontSize: "13px", color: "#0c211d" }}>
                  <strong>Time:</strong> {selectedSessionForModal.time}
                </div>
                <div style={{ fontSize: "13px", color: "#0c211d" }}>
                  <strong>Batch:</strong> {selectedSessionForModal.class || "Class 10 — Section A"}
                </div>
                <div style={{ fontSize: "13px", color: "#0c211d" }}>
                  <strong>Platform:</strong> SARTHI Virtual Classroom Studio
                </div>
              </div>

              <div style={{ display: "flex", gap: "10px" }}>
                <a
                  href="https://meet.sarthi.gov.in"
                  target="_blank"
                  rel="noreferrer"
                  style={{
                    flex: 1,
                    padding: "10px",
                    borderRadius: "10px",
                    background: "#059669",
                    color: "#fff",
                    fontWeight: "700",
                    fontSize: "13px",
                    textAlign: "center",
                    textDecoration: "none",
                  }}
                >
                  Join / Start Session
                </a>
                <button
                  type="button"
                  onClick={() => setSelectedSessionForModal(null)}
                  style={{
                    padding: "10px 16px",
                    borderRadius: "10px",
                    background: "#f1f5f9",
                    border: "none",
                    fontWeight: "700",
                    fontSize: "13px",
                    color: "#475569",
                    cursor: "pointer",
                  }}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </TrainerShell>
  );
}
