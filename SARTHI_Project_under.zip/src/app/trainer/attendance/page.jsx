"use client";

import React, { useState, useMemo, useEffect } from "react";
import TrainerShell from "@/components/trainer/TrainerShell";
import { useTrainer } from "@/lib/services/TrainerContext";

export default function TrainerAttendancePage() {
  const { trainees, courses, fetchAttendance, saveAttendanceRecords } = useTrainer();
  const [searchQuery, setSearchQuery] = useState("");

  // Date Navigation state (Section 16)
  const [currentDate, setCurrentDate] = useState(new Date(2026, 8, 8)); // September 8, 2026
  const [selectedCourseId, setSelectedCourseId] = useState(courses[0]?.id || "course-math-10");
  const [selectedBatch, setSelectedBatch] = useState("Class 10 — Section A");

  // Local Attendance State for active roster
  const [attendanceList, setAttendanceList] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState("");
  const [showBulkConfirmModal, setShowBulkConfirmModal] = useState(false);

  // Format date strings
  const dateKey = useMemo(() => {
    return currentDate.toISOString().split("T")[0];
  }, [currentDate]);

  const formattedDateTitle = useMemo(() => {
    return currentDate.toLocaleDateString("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric",
    });
  }, [currentDate]);

  // Initialize or fetch attendance on date/course change
  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      const backendData = await fetchAttendance(dateKey, selectedCourseId);
      if (isMounted) {
        if (backendData?.students && backendData.students.length > 0) {
          setAttendanceList(backendData.students);
        } else {
          // Fallback to local trainees with baseline statuses
          const initial = trainees.map((t) => ({
            studentId: t.id,
            studentName: t.name,
            studentEmail: t.email,
            studentAvatar: t.avatar,
            class: t.class || selectedBatch,
            status: t.status || "PRESENT", // 'PRESENT' | 'ABSENT' | 'LATE'
            remarks: t.remarks || "",
            attendanceRate: t.attendance || 92,
          }));
          setAttendanceList(initial);
        }
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, [dateKey, selectedCourseId, trainees, fetchAttendance, selectedBatch]);

  // Date navigation handlers (Section 16)
  const handlePrevDay = () => {
    const next = new Date(currentDate);
    next.setDate(next.getDate() - 1);
    setCurrentDate(next);
  };

  const handleNextDay = () => {
    const next = new Date(currentDate);
    next.setDate(next.getDate() + 1);
    setCurrentDate(next);
  };

  const handleToday = () => {
    setCurrentDate(new Date(2026, 8, 8));
  };

  // Status Change handler
  const handleStatusChange = (studentId, newStatus) => {
    setAttendanceList((prev) =>
      prev.map((item) => {
        if (item.studentId === studentId) {
          return { ...item, status: newStatus };
        }
        return item;
      })
    );
  };

  const handleRemarksChange = (studentId, remarks) => {
    setAttendanceList((prev) =>
      prev.map((item) => {
        if (item.studentId === studentId) {
          return { ...item, remarks };
        }
        return item;
      })
    );
  };

  // Bulk Actions (Section 18)
  const handleMarkAllPresent = () => {
    setAttendanceList((prev) =>
      prev.map((item) => ({ ...item, status: "PRESENT" }))
    );
    setShowBulkConfirmModal(false);
    triggerSuccessBanner("Marked all students as Present.");
  };

  const handleMarkAllAbsent = () => {
    setAttendanceList((prev) =>
      prev.map((item) => ({ ...item, status: "ABSENT" }))
    );
    triggerSuccessBanner("Marked all students as Absent.");
  };

  const handleResetAttendance = () => {
    const reset = trainees.map((t) => ({
      studentId: t.id,
      studentName: t.name,
      studentEmail: t.email,
      studentAvatar: t.avatar,
      class: t.class || selectedBatch,
      status: "PRESENT",
      remarks: "",
      attendanceRate: t.attendance || 92,
    }));
    setAttendanceList(reset);
    triggerSuccessBanner("Attendance roster reset.");
  };

  const handleSaveAttendance = async () => {
    setIsSaving(true);
    await saveAttendanceRecords(dateKey, attendanceList, selectedCourseId);
    setIsSaving(false);
    triggerSuccessBanner("✓ Attendance saved successfully for " + formattedDateTitle);
  };

  const triggerSuccessBanner = (msg) => {
    setSaveSuccessMsg(msg);
    setTimeout(() => setSaveSuccessMsg(""), 3000);
  };

  // Attendance Summary Metrics (Section 19)
  const summary = useMemo(() => {
    const total = attendanceList.length;
    const present = attendanceList.filter((s) => s.status === "PRESENT").length;
    const absent = attendanceList.filter((s) => s.status === "ABSENT").length;
    const late = attendanceList.filter((s) => s.status === "LATE").length;
    const rate = total > 0 ? Math.round(((present + late * 0.5) / total) * 100) : 91;

    return { total, present, absent, late, rate };
  }, [attendanceList]);

  // Search filtering
  const filteredList = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return attendanceList;
    return attendanceList.filter(
      (s) =>
        s.studentName.toLowerCase().includes(q) ||
        (s.remarks && s.remarks.toLowerCase().includes(q))
    );
  }, [attendanceList, searchQuery]);

  return (
    <TrainerShell searchQuery={searchQuery} setSearchQuery={setSearchQuery} placeholder="Search student by name or remarks...">
      <div style={{ padding: "28px 36px 64px 36px", maxWidth: "1360px", margin: "0 auto", width: "100%" }}>
        {/* Success Toast Banner */}
        {saveSuccessMsg && (
          <div
            style={{
              padding: "12px 18px",
              background: "#dcfce7",
              border: "1px solid #86efac",
              borderRadius: "12px",
              color: "#166534",
              fontWeight: "700",
              fontSize: "13.5px",
              marginBottom: "20px",
              display: "flex",
              alignItems: "center",
              gap: "8px",
            }}
          >
            <span>{saveSuccessMsg}</span>
          </div>
        )}

        {/* ==========================================================================
            1. TOP BAR: Class selector & Date Navigator (Section 16)
            ========================================================================== */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            marginBottom: "24px",
            flexWrap: "wrap",
            gap: "16px",
          }}
        >
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
              <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#10b981" }} />
              <span style={{ fontSize: "11px", fontWeight: "800", color: "#065f46", letterSpacing: "0.12em", textTransform: "uppercase" }}>
                CLASSROOM REGISTRY
              </span>
            </div>
            <h1 style={{ fontSize: "28px", fontWeight: "800", color: "#0a2920", margin: "0 0 6px 0", letterSpacing: "-0.5px" }}>
              Classroom Attendance
            </h1>
            <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
              <span style={{ fontSize: "14px", fontWeight: "700", color: "#059669" }}>
                Mathematics — Class 10 — Section A
              </span>
              <span style={{ color: "#cbd5e1" }}>•</span>
              <span style={{ fontSize: "13.5px", color: "#64748b" }}>
                {summary.total} Enrolled Students
              </span>
            </div>
          </div>

          {/* Date Navigator (Section 16: [< Previous] [Today] [Next >]) */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              background: "#ffffff",
              border: "1px solid var(--sarthi-border, #e8f0eb)",
              padding: "6px 10px",
              borderRadius: "14px",
              boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
            }}
          >
            <button
              type="button"
              onClick={handlePrevDay}
              style={{
                border: "none",
                background: "#f1f5f9",
                borderRadius: "8px",
                padding: "6px 12px",
                fontSize: "12px",
                fontWeight: "700",
                color: "#334155",
                cursor: "pointer",
              }}
            >
              &lt; Previous
            </button>

            <button
              type="button"
              onClick={handleToday}
              style={{
                border: "none",
                background: "#ecfdf5",
                color: "#059669",
                borderRadius: "8px",
                padding: "6px 14px",
                fontSize: "12.5px",
                fontWeight: "800",
                cursor: "pointer",
              }}
            >
              Today
            </button>

            <button
              type="button"
              onClick={handleNextDay}
              style={{
                border: "none",
                background: "#f1f5f9",
                borderRadius: "8px",
                padding: "6px 12px",
                fontSize: "12px",
                fontWeight: "700",
                color: "#334155",
                cursor: "pointer",
              }}
            >
              Next &gt;
            </button>

            <span style={{ marginLeft: "6px", fontSize: "13px", fontWeight: "700", color: "#0c211d", paddingRight: "6px" }}>
              {formattedDateTitle}
            </span>
          </div>
        </div>

        {/* ==========================================================================
            2. ATTENDANCE SUMMARY METRICS WITH LIGHTWEIGHT GAUGE (Section 19)
            ========================================================================== */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
            gap: "14px",
            marginBottom: "24px",
          }}
        >
          {/* Card: Present */}
          <div className="edtech-kpi-card" style={{ borderLeft: "4px solid #059669" }}>
            <div className="edtech-kpi-header">
              <span style={{ fontSize: "12px", fontWeight: "800", color: "#065f46", textTransform: "uppercase" }}>
                Present
              </span>
              <span style={{ fontSize: "12px", fontWeight: "700", color: "#059669", background: "#dcfce7", padding: "2px 8px", borderRadius: "999px" }}>
                ● On-Time
              </span>
            </div>
            <div className="edtech-kpi-val" style={{ color: "#059669" }}>
              {summary.present}
            </div>
            <div className="edtech-kpi-desc">Trainees present in class</div>
          </div>

          {/* Card: Absent */}
          <div className="edtech-kpi-card" style={{ borderLeft: "4px solid #dc2626" }}>
            <div className="edtech-kpi-header">
              <span style={{ fontSize: "12px", fontWeight: "800", color: "#991b1b", textTransform: "uppercase" }}>
                Absent
              </span>
              <span style={{ fontSize: "12px", fontWeight: "700", color: "#dc2626", background: "#fee2e2", padding: "2px 8px", borderRadius: "999px" }}>
                ● Missing
              </span>
            </div>
            <div className="edtech-kpi-val" style={{ color: "#dc2626" }}>
              {summary.absent}
            </div>
            <div className="edtech-kpi-desc">Leaves or unexcused absence</div>
          </div>

          {/* Card: Late */}
          <div className="edtech-kpi-card" style={{ borderLeft: "4px solid #d97706" }}>
            <div className="edtech-kpi-header">
              <span style={{ fontSize: "12px", fontWeight: "800", color: "#92400e", textTransform: "uppercase" }}>
                Late Arrival
              </span>
              <span style={{ fontSize: "12px", fontWeight: "700", color: "#d97706", background: "#fef3c7", padding: "2px 8px", borderRadius: "999px" }}>
                ● Delayed
              </span>
            </div>
            <div className="edtech-kpi-val" style={{ color: "#d97706" }}>
              {summary.late}
            </div>
            <div className="edtech-kpi-desc">Joined session after roll call</div>
          </div>

          {/* Card: Attendance Rate with Lightweight SVG Gauge Ring (Section 19) */}
          <div className="edtech-kpi-card" style={{ display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <span style={{ fontSize: "12px", fontWeight: "800", color: "#64748b", textTransform: "uppercase" }}>
                Attendance Rate
              </span>
              <div className="edtech-kpi-val" style={{ marginTop: "4px" }}>
                {summary.rate}%
              </div>
              <div className="edtech-kpi-desc" style={{ marginTop: "4px" }}>
                Cohort attendance index
              </div>
            </div>

            {/* Circular Gauge Graphic (No external heavy chart library) */}
            <div style={{ position: "relative", width: "64px", height: "64px" }}>
              <svg width="64" height="64" viewBox="0 0 36 36">
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#e2e8f0"
                  strokeWidth="3.5"
                />
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#059669"
                  strokeWidth="3.5"
                  strokeDasharray={`${summary.rate}, 100`}
                  strokeLinecap="round"
                />
              </svg>
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "11px",
                  fontWeight: "800",
                  color: "#0c211d",
                }}
              >
                {summary.rate}%
              </div>
            </div>
          </div>
        </div>

        {/* ==========================================================================
            3. BULK ATTENDANCE ACTION BAR (Section 18)
            ========================================================================== */}
        <div
          style={{
            background: "#ffffff",
            border: "1px solid var(--sarthi-border, #e8f0eb)",
            borderRadius: "16px",
            padding: "14px 20px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "20px",
            flexWrap: "wrap",
            gap: "12px",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "10px", flexWrap: "wrap" }}>
            <span style={{ fontSize: "12.5px", fontWeight: "700", color: "#64748b" }}>Bulk Actions:</span>

            <button
              type="button"
              onClick={() => setShowBulkConfirmModal(true)}
              style={{
                padding: "7px 14px",
                borderRadius: "8px",
                background: "#ecfdf5",
                border: "1px solid #bbf7d0",
                color: "#065f46",
                fontSize: "12.5px",
                fontWeight: "700",
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: "6px",
              }}
            >
              <span>✓</span>
              <span>Mark All Present</span>
            </button>

            <button
              type="button"
              onClick={handleMarkAllAbsent}
              style={{
                padding: "7px 14px",
                borderRadius: "8px",
                background: "#fef2f2",
                border: "1px solid #fecaca",
                color: "#991b1b",
                fontSize: "12.5px",
                fontWeight: "700",
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: "6px",
              }}
            >
              <span>✕</span>
              <span>Mark All Absent</span>
            </button>

            <button
              type="button"
              onClick={handleResetAttendance}
              style={{
                padding: "7px 14px",
                borderRadius: "8px",
                background: "#f1f5f9",
                border: "none",
                color: "#475569",
                fontSize: "12.5px",
                fontWeight: "700",
                cursor: "pointer",
              }}
            >
              Reset
            </button>
          </div>

          <button
            type="button"
            onClick={handleSaveAttendance}
            disabled={isSaving}
            className="db-btn-primary"
            style={{
              padding: "9px 22px",
              borderRadius: "10px",
              background: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
              color: "#ffffff",
              fontSize: "13px",
              fontWeight: "700",
              border: "none",
              cursor: "pointer",
              boxShadow: "0 2px 8px rgba(5, 150, 105, 0.25)",
            }}
          >
            {isSaving ? "Saving..." : "Save Attendance"}
          </button>
        </div>

        {/* ==========================================================================
            4. ATTENDANCE TABLE WITH SEGMENTED CONTROLS (Section 17)
            ========================================================================== */}
        <div style={{ background: "#ffffff", border: "1px solid var(--sarthi-border, #e8f0eb)", borderRadius: "20px", padding: "20px", boxShadow: "0 1px 3px rgba(0,0,0,0.02)" }}>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "13px" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid #e2e8f0", background: "#f8faf9" }}>
                  <th style={{ padding: "12px 16px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase" }}>Student</th>
                  <th style={{ padding: "12px 16px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase" }}>Attendance Status</th>
                  <th style={{ padding: "12px 16px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase" }}>Remarks / Notes</th>
                  <th style={{ padding: "12px 16px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase", textAlign: "right" }}>Attendance %</th>
                </tr>
              </thead>
              <tbody>
                {filteredList.map((item) => (
                  <tr key={item.studentId} style={{ borderBottom: "1px solid #f1f5f9", transition: "background 0.15s ease" }}>
                    {/* Student Column */}
                    <td style={{ padding: "12px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                        <img
                          src={item.studentAvatar || "/images/student-img-1.jpg"}
                          alt={item.studentName}
                          style={{ width: "34px", height: "34px", borderRadius: "50%", objectFit: "cover" }}
                        />
                        <div>
                          <div style={{ fontWeight: "700", color: "#0c211d", fontSize: "13.5px" }}>
                            {item.studentName}
                          </div>
                          <div style={{ fontSize: "11.5px", color: "#64748b" }}>
                            {item.studentEmail || "student@sarthi.edu.in"}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Segmented Status Buttons [P] [A] [L] (Section 17) */}
                    <td style={{ padding: "12px 16px" }}>
                      <div className="segmented-status-group">
                        <button
                          type="button"
                          onClick={() => handleStatusChange(item.studentId, "PRESENT")}
                          className={`segmented-btn present ${item.status === "PRESENT" ? "active" : ""}`}
                          aria-label={`Mark ${item.studentName} Present`}
                        >
                          <span>●</span>
                          <span>[P] Present</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item.studentId, "ABSENT")}
                          className={`segmented-btn absent ${item.status === "ABSENT" ? "active" : ""}`}
                          aria-label={`Mark ${item.studentName} Absent`}
                        >
                          <span>✕</span>
                          <span>[A] Absent</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(item.studentId, "LATE")}
                          className={`segmented-btn late ${item.status === "LATE" ? "active" : ""}`}
                          aria-label={`Mark ${item.studentName} Late`}
                        >
                          <span>⏱</span>
                          <span>[L] Late</span>
                        </button>
                      </div>
                    </td>

                    {/* Remarks Input */}
                    <td style={{ padding: "12px 16px" }}>
                      <input
                        type="text"
                        placeholder="Add reason or note..."
                        value={item.remarks}
                        onChange={(e) => handleRemarksChange(item.studentId, e.target.value)}
                        style={{
                          width: "100%",
                          maxWidth: "260px",
                          padding: "6px 10px",
                          borderRadius: "8px",
                          border: "1px solid #e2e8f0",
                          fontSize: "12.5px",
                          outline: "none",
                          background: "#f8faf9",
                        }}
                      />
                    </td>

                    {/* Historical Attendance % (Section 17) */}
                    <td style={{ padding: "12px 16px", textAlign: "right" }}>
                      <span
                        style={{
                          fontSize: "13px",
                          fontWeight: "800",
                          color: item.attendanceRate >= 90 ? "#059669" : item.attendanceRate >= 80 ? "#d97706" : "#dc2626",
                        }}
                      >
                        {item.attendanceRate}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal: Bulk Present Confirmation */}
        {showBulkConfirmModal && (
          <div
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(12, 33, 29, 0.4)",
              backdropFilter: "blur(6px)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 1000,
              padding: "20px",
            }}
            onClick={() => setShowBulkConfirmModal(false)}
          >
            <div
              style={{
                background: "#ffffff",
                borderRadius: "20px",
                padding: "28px",
                width: "100%",
                maxWidth: "420px",
                boxShadow: "0 25px 50px -12px rgba(0,0,0,0.25)",
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <h3 style={{ fontSize: "18px", fontWeight: "800", color: "#0c211d", margin: "0 0 8px 0" }}>
                Mark All Present?
              </h3>
              <p style={{ fontSize: "13.5px", color: "#64748b", margin: "0 0 20px 0" }}>
                This will set all {attendanceList.length} enrolled students in {selectedBatch} as Present for {formattedDateTitle}.
              </p>

              <div style={{ display: "flex", gap: "10px" }}>
                <button
                  type="button"
                  onClick={handleMarkAllPresent}
                  style={{
                    flex: 1,
                    padding: "10px",
                    borderRadius: "10px",
                    background: "#059669",
                    color: "#ffffff",
                    fontWeight: "700",
                    fontSize: "13px",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Yes, Mark All Present
                </button>
                <button
                  type="button"
                  onClick={() => setShowBulkConfirmModal(false)}
                  style={{
                    padding: "10px 16px",
                    borderRadius: "10px",
                    background: "#f1f5f9",
                    border: "none",
                    fontWeight: "700",
                    fontSize: "13px",
                    color: "#475569",
                    cursor: "pointer",
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </TrainerShell>
  );
}
