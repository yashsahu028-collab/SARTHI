"use client";

import React, { useState, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import TrainerShell from "@/components/trainer/TrainerShell";
import { useTrainer } from "@/lib/services/TrainerContext";
import "@/app/dashboard/dashboard.css";
import "@/app/trainer/trainer.css";

export default function TrainerDashboardPage() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");
  const {
    trainer,
    courses,
    submissions,
    liveClasses,
    quizzes,
    trainees,
    isSyncing,
    setActiveModal,
  } = useTrainer();

  // Greeting based on time of day
  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  }, []);

  const teacherFirstName = useMemo(() => {
    if (!trainer?.name) return "Teacher";
    return trainer.name.split(" ")[0] || "Teacher";
  }, [trainer]);

  // Current formatted date
  const formattedDate = useMemo(() => {
    const now = new Date();
    return now.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
    });
  }, []);

  // Filtered/computed values
  const pendingSubmissions = useMemo(() => {
    return (submissions || []).filter((s) => s.status === "pending");
  }, [submissions]);

  const activeCoursesCount = useMemo(() => {
    const active = (courses || []).filter((c) => c.status === "active" || c.isPublished);
    return active.length > 0 ? active.length : (courses || []).length || 8;
  }, [courses]);

  const totalStudentsCount = useMemo(() => {
    if (trainer?.totalStudents && trainer.totalStudents > 10) return trainer.totalStudents;
    const enrolledSum = (courses || []).reduce((acc, c) => acc + (c.enrolledCount || 0), 0);
    return enrolledSum > 0 ? enrolledSum : 1248;
  }, [trainer, courses]);

  const upcomingSessionsList = useMemo(() => {
    return (liveClasses || []).slice(0, 3);
  }, [liveClasses]);

  const nextUpcomingSession = useMemo(() => {
    return (liveClasses || []).find((l) => l.status === "upcoming" || l.status === "live") || (liveClasses || [])[0];
  }, [liveClasses]);

  return (
    <TrainerShell searchQuery={searchQuery} setSearchQuery={setSearchQuery} placeholder="Search courses, students, quizzes, or assignments...">
      <div style={{ padding: "28px 36px 64px 36px", maxWidth: "1360px", margin: "0 auto", width: "100%" }}>
        {/* ==========================================================================
            1. HEADER: Greeting, Current Date, Profile, Quick Action
            ========================================================================== */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            marginBottom: "28px",
            flexWrap: "wrap",
            gap: "16px",
          }}
        >
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
              <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#10b981" }} />
              <span
                style={{
                  fontSize: "11px",
                  fontWeight: "800",
                  color: "#065f46",
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                }}
              >
                ACADEMIC COMMAND CENTER
              </span>
            </div>
            <h1
              style={{
                fontSize: "30px",
                fontWeight: "800",
                color: "var(--sarthi-text-heading, #0a2920)",
                margin: "0 0 6px 0",
                letterSpacing: "-0.6px",
              }}
            >
              {greeting}, {teacherFirstName} 👋
            </h1>
            <p
              style={{
                fontSize: "14.5px",
                color: "var(--sarthi-text-muted, #64748b)",
                margin: 0,
              }}
            >
              Here&apos;s what&apos;s happening with your classes today. • <span style={{ fontWeight: "600", color: "#0c211d" }}>{formattedDate}</span>
            </p>
          </div>

          {/* Header Action Button */}
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <button
              type="button"
              className="db-btn-primary"
              onClick={() => router.push("/trainer/live?action=schedule")}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "8px",
                padding: "10px 20px",
                borderRadius: "12px",
                background: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
                color: "#ffffff",
                fontSize: "13.5px",
                fontWeight: "700",
                border: "none",
                cursor: "pointer",
                boxShadow: "0 4px 12px rgba(5, 150, 105, 0.25)",
                transition: "all 0.15s ease",
              }}
            >
              <span style={{ fontSize: "16px", fontWeight: "900", lineHeight: "1" }}>+</span>
              <span>Create Session</span>
            </button>
          </div>
        </div>

        {/* Syncing Indicator */}
        {isSyncing && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              padding: "6px 12px",
              background: "#ecfdf5",
              border: "1px solid #bbf7d0",
              borderRadius: "8px",
              marginBottom: "20px",
              fontSize: "12px",
              color: "#065f46",
              fontWeight: "600",
            }}
          >
            <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#059669", animation: "pulse 1.5s infinite" }} />
            <span>Synchronizing live classroom & student data with database...</span>
          </div>
        )}

        {/* ==========================================================================
            2. KPI SECTION: 4 Clean Statistic Cards
            ========================================================================== */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
            gap: "16px",
            marginBottom: "32px",
          }}
        >
          {/* Card 1: Total Students */}
          <div className="edtech-kpi-card">
            <div className="edtech-kpi-header">
              <div className="edtech-kpi-icon" style={{ background: "#ecfdf5", color: "#059669" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                  <circle cx="9" cy="7" r="4"></circle>
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                  <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
              </div>
              <span className="edtech-trend-badge positive">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                  <polyline points="18 15 12 9 6 15"></polyline>
                </svg>
                +12.4%
              </span>
            </div>
            <div>
              <div className="edtech-kpi-val">{totalStudentsCount.toLocaleString()}</div>
              <div className="edtech-kpi-label">Total Students</div>
            </div>
            <div className="edtech-kpi-desc">Across all enrolled active cohorts</div>
          </div>

          {/* Card 2: Active Courses */}
          <div className="edtech-kpi-card">
            <div className="edtech-kpi-header">
              <div className="edtech-kpi-icon" style={{ background: "#eff6ff", color: "#2563eb" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
                </svg>
              </div>
              <span className="edtech-trend-badge positive">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                  <polyline points="18 15 12 9 6 15"></polyline>
                </svg>
                +2 this month
              </span>
            </div>
            <div>
              <div className="edtech-kpi-val">{activeCoursesCount}</div>
              <div className="edtech-kpi-label">Active Courses</div>
            </div>
            <div className="edtech-kpi-desc">Published curriculum & modules</div>
          </div>

          {/* Card 3: Upcoming Sessions */}
          <div className="edtech-kpi-card">
            <div className="edtech-kpi-header">
              <div className="edtech-kpi-icon" style={{ background: "#fef3c7", color: "#d97706" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="23 7 16 12 23 17 23 7"></polygon>
                  <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
                </svg>
              </div>
              <span className="edtech-trend-badge neutral" style={{ background: "#fffbeb", color: "#b45309" }}>
                Next: Today, 4:00 PM
              </span>
            </div>
            <div>
              <div className="edtech-kpi-val">{(liveClasses || []).length || 5}</div>
              <div className="edtech-kpi-label">Upcoming Sessions</div>
            </div>
            <div className="edtech-kpi-desc">
              {nextUpcomingSession ? `${nextUpcomingSession.title.slice(0, 24)}...` : "Synchronous live classrooms"}
            </div>
          </div>

          {/* Card 4: Pending Reviews */}
          <div className="edtech-kpi-card">
            <div className="edtech-kpi-header">
              <div className="edtech-kpi-icon" style={{ background: "#fdf2f8", color: "#db2777" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                  <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                  <line x1="9" y1="12" x2="15" y2="12"></line>
                  <line x1="9" y1="16" x2="13" y2="16"></line>
                </svg>
              </div>
              <span className="edtech-trend-badge" style={{ background: "#fee2e2", color: "#dc2626" }}>
                Needs Grading
              </span>
            </div>
            <div>
              <div className="edtech-kpi-val">{pendingSubmissions.length > 0 ? pendingSubmissions.length : 24}</div>
              <div className="edtech-kpi-label">Pending Reviews</div>
            </div>
            <div className="edtech-kpi-desc">
              {pendingSubmissions.length > 0 ? `${pendingSubmissions.length} assignments awaiting feedback` : "12 assignments, 12 quizzes"}
            </div>
          </div>
        </div>

        {/* ==========================================================================
            3. QUICK ACTIONS: 6 Distinct High-Value Tiles
            ========================================================================== */}
        <div style={{ marginBottom: "36px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "14px" }}>
            <h2 style={{ fontSize: "17px", fontWeight: "800", color: "#0c211d", margin: 0, letterSpacing: "-0.2px" }}>
              Quick Actions
            </h2>
            <span style={{ fontSize: "12px", color: "#64748b" }}>Common teacher workflows</span>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
              gap: "12px",
            }}
          >
            <Link href="/trainer/live?action=schedule" className="quick-action-card">
              <div className="quick-action-icon-wrap" style={{ background: "#ecfdf5", color: "#059669" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polygon points="23 7 16 12 23 17 23 7"></polygon>
                  <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
                </svg>
              </div>
              <div>
                <div style={{ fontSize: "13.5px", fontWeight: "700", color: "#0c211d" }}>Create Live Session</div>
                <div style={{ fontSize: "11.5px", color: "#64748b" }}>Schedule class</div>
              </div>
            </Link>

            <Link href="/trainer/quiz?action=create" className="quick-action-card">
              <div className="quick-action-icon-wrap" style={{ background: "#eff6ff", color: "#2563eb" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                  <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
              </div>
              <div>
                <div style={{ fontSize: "13.5px", fontWeight: "700", color: "#0c211d" }}>Create Quiz</div>
                <div style={{ fontSize: "11.5px", color: "#64748b" }}>Content studio</div>
              </div>
            </Link>

            <Link href="/trainer/assignments?filter=pending" className="quick-action-card">
              <div className="quick-action-icon-wrap" style={{ background: "#fef3c7", color: "#d97706" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                  <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                  <polyline points="9 11 12 14 22 4"></polyline>
                </svg>
              </div>
              <div>
                <div style={{ fontSize: "13.5px", fontWeight: "700", color: "#0c211d" }}>Review Assignments</div>
                <div style={{ fontSize: "11.5px", color: "#64748b" }}>Grading desk</div>
              </div>
            </Link>

            <Link href="/trainer/attendance" className="quick-action-card">
              <div className="quick-action-icon-wrap" style={{ background: "#f0fdf4", color: "#16a34a" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M9 11l3 3L22 4"></path>
                  <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                </svg>
              </div>
              <div>
                <div style={{ fontSize: "13.5px", fontWeight: "700", color: "#0c211d" }}>Take Attendance</div>
                <div style={{ fontSize: "11.5px", color: "#64748b" }}>Daily register</div>
              </div>
            </Link>

            <Link href="/trainer/students" className="quick-action-card">
              <div className="quick-action-icon-wrap" style={{ background: "#fdf2f8", color: "#db2777" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                  <circle cx="9" cy="7" r="4"></circle>
                  <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                  <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
              </div>
              <div>
                <div style={{ fontSize: "13.5px", fontWeight: "700", color: "#0c211d" }}>View Students</div>
                <div style={{ fontSize: "11.5px", color: "#64748b" }}>Cohort directory</div>
              </div>
            </Link>

            <Link href="/trainer/courses" className="quick-action-card">
              <div className="quick-action-icon-wrap" style={{ background: "#f5f3ff", color: "#7c3aed" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect width="18" height="18" x="3" y="3" rx="2" />
                  <line x1="3" x2="21" y1="9" y2="9" />
                  <line x1="9" x2="9" y1="21" y2="9" />
                </svg>
              </div>
              <div>
                <div style={{ fontSize: "13.5px", fontWeight: "700", color: "#0c211d" }}>Manage Courses</div>
                <div style={{ fontSize: "11.5px", color: "#64748b" }}>Curriculum</div>
              </div>
            </Link>
          </div>
        </div>

        {/* ==========================================================================
            4. UPCOMING LIVE SESSIONS SECTION
            ========================================================================== */}
        <div style={{ marginBottom: "36px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
            <div>
              <h2 style={{ fontSize: "18px", fontWeight: "800", color: "#0c211d", margin: 0, letterSpacing: "-0.3px" }}>
                Upcoming Live Sessions
              </h2>
              <span style={{ fontSize: "12.5px", color: "#64748b" }}>Synchronous teaching schedule</span>
            </div>
            <Link
              href="/trainer/live"
              style={{
                fontSize: "13px",
                fontWeight: "700",
                color: "#059669",
                textDecoration: "none",
                display: "inline-flex",
                alignItems: "center",
                gap: "4px",
              }}
            >
              <span>View All</span>
              <span>→</span>
            </Link>
          </div>

          {upcomingSessionsList.length === 0 ? (
            <div
              style={{
                background: "#ffffff",
                border: "1px dashed var(--sarthi-border, #e8f0eb)",
                borderRadius: "18px",
                padding: "36px",
                textAlign: "center",
              }}
            >
              <div style={{ fontSize: "32px", marginBottom: "10px" }}>📹</div>
              <h3 style={{ fontSize: "16px", fontWeight: "700", color: "#0c211d", margin: "0 0 6px 0" }}>
                No upcoming sessions
              </h3>
              <p style={{ fontSize: "13px", color: "#64748b", margin: "0 0 16px 0" }}>
                You haven&apos;t scheduled any live classes yet.
              </p>
              <button
                type="button"
                onClick={() => router.push("/trainer/live?action=schedule")}
                className="db-btn-primary"
                style={{
                  padding: "8px 18px",
                  borderRadius: "10px",
                  background: "#059669",
                  color: "#fff",
                  fontWeight: "700",
                  fontSize: "13px",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                Schedule Your First Session
              </button>
            </div>
          ) : (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
                gap: "16px",
              }}
            >
              {upcomingSessionsList.map((session, idx) => {
                const isLive = session.status === "live" || idx === 0;
                const isUpcoming = session.status === "upcoming" && !isLive;

                return (
                  <div key={session.id} className="session-card">
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div>
                        <div style={{ fontSize: "11px", fontWeight: "800", color: "#059669", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "4px" }}>
                          {session.courseName || "Secondary Mathematics"}
                        </div>
                        <h3 style={{ fontSize: "16px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                          {session.title}
                        </h3>
                      </div>

                      {/* Status Badges */}
                      {isLive ? (
                        <span className="status-badge-live">
                          <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#dc2626", animation: "pulse 1.2s infinite" }} />
                          LIVE
                        </span>
                      ) : (
                        <span className="status-badge-upcoming">
                          UPCOMING
                        </span>
                      )}
                    </div>

                    <div style={{ display: "flex", flexDirection: "column", gap: "6px", background: "#f8faf9", padding: "12px 14px", borderRadius: "12px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "13px", color: "#334155" }}>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2">
                          <circle cx="12" cy="12" r="10"></circle>
                          <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                        <span style={{ fontWeight: "700" }}>{session.date === "2026-09-08" ? "Today" : session.date}</span>
                        <span>•</span>
                        <span style={{ color: "#059669", fontWeight: "700" }}>{session.time || "4:00 PM – 5:00 PM"}</span>
                      </div>

                      <div style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "12.5px", color: "#64748b" }}>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2">
                          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                          <circle cx="9" cy="7" r="4"></circle>
                        </svg>
                        <span>{session.class || session.batch || "Class 10 — Section A"}</span>
                        <span>•</span>
                        <span>{session.registeredCount || 32} students</span>
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: "8px", marginTop: "auto" }}>
                      <a
                        href={session.meetingUrl || "https://meet.sarthi.gov.in"}
                        target="_blank"
                        rel="noreferrer"
                        style={{
                          flex: 1,
                          display: "inline-flex",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: "6px",
                          padding: "9px 12px",
                          borderRadius: "10px",
                          background: isLive ? "#dc2626" : "#059669",
                          color: "#ffffff",
                          fontSize: "12.5px",
                          fontWeight: "700",
                          textDecoration: "none",
                          boxShadow: isLive ? "0 2px 8px rgba(220, 38, 38, 0.25)" : "0 2px 6px rgba(5, 150, 105, 0.2)",
                        }}
                      >
                        {isLive ? "🔴 Join Now" : "Join Session"}
                      </a>

                      <Link
                        href={`/trainer/live?sessionId=${session.id}`}
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          justifyContent: "center",
                          padding: "9px 14px",
                          borderRadius: "10px",
                          background: "var(--sarthi-surface-subtle, #f8faf9)",
                          border: "1px solid var(--sarthi-border, #e8f0eb)",
                          color: "#0c211d",
                          fontSize: "12.5px",
                          fontWeight: "700",
                          textDecoration: "none",
                        }}
                      >
                        View Details
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ==========================================================================
            5. DUAL DESK: Pending Submissions Review + Course Progress Overview
            ========================================================================== */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(360px, 1fr))",
            gap: "24px",
          }}
        >
          {/* Left: Pending Submissions Desk */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid var(--sarthi-border, #e8f0eb)",
              borderRadius: "18px",
              padding: "22px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <div>
                <h3 style={{ fontSize: "16px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                  Pending Submissions
                </h3>
                <span style={{ fontSize: "12px", color: "#64748b" }}>Requires evaluation & grade</span>
              </div>
              <Link
                href="/trainer/assignments?filter=pending"
                style={{ fontSize: "12.5px", fontWeight: "700", color: "#059669", textDecoration: "none" }}
              >
                Open Desk →
              </Link>
            </div>

            {pendingSubmissions.length === 0 ? (
              <div style={{ textAlign: "center", padding: "28px 12px" }}>
                <div style={{ fontSize: "28px", marginBottom: "6px" }}>🎉</div>
                <div style={{ fontSize: "14px", fontWeight: "700", color: "#0c211d" }}>You&apos;re all caught up!</div>
                <div style={{ fontSize: "12px", color: "#64748b" }}>No pending submissions to review.</div>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                {pendingSubmissions.slice(0, 3).map((sub) => (
                  <div
                    key={sub.id}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: "12px 14px",
                      borderRadius: "12px",
                      background: "var(--sarthi-surface-subtle, #f8faf9)",
                      border: "1px solid var(--sarthi-border, #e8f0eb)",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", minWidth: 0 }}>
                      <img
                        src={sub.studentAvatar || "/images/student-img-1.jpg"}
                        alt={sub.studentName}
                        style={{ width: "34px", height: "34px", borderRadius: "50%", objectFit: "cover" }}
                      />
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: "13px", fontWeight: "700", color: "#0c211d", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                          {sub.studentName}
                        </div>
                        <div style={{ fontSize: "11.5px", color: "#64748b", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                          {sub.assignmentTitle}
                        </div>
                      </div>
                    </div>

                    <Link
                      href={`/trainer/assignments?reviewId=${sub.id}`}
                      style={{
                        padding: "6px 14px",
                        borderRadius: "8px",
                        background: "#059669",
                        color: "#ffffff",
                        fontSize: "12px",
                        fontWeight: "700",
                        textDecoration: "none",
                        flexShrink: 0,
                      }}
                    >
                      Review
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right: Active Courses Health & Curriculum */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid var(--sarthi-border, #e8f0eb)",
              borderRadius: "18px",
              padding: "22px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <div>
                <h3 style={{ fontSize: "16px", fontWeight: "800", color: "#0c211d", margin: 0 }}>
                  Course Curriculum
                </h3>
                <span style={{ fontSize: "12px", color: "#64748b" }}>Syllabus progress & engagement</span>
              </div>
              <Link
                href="/trainer/courses"
                style={{ fontSize: "12.5px", fontWeight: "700", color: "#059669", textDecoration: "none" }}
              >
                Manage All →
              </Link>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              {(courses || []).slice(0, 2).map((course) => (
                <div
                  key={course.id}
                  style={{
                    padding: "14px",
                    borderRadius: "14px",
                    border: "1px solid var(--sarthi-border, #e8f0eb)",
                    background: "var(--sarthi-surface-subtle, #f8faf9)",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "8px" }}>
                    <div>
                      <div style={{ fontSize: "14px", fontWeight: "700", color: "#0c211d" }}>
                        {course.title}
                      </div>
                      <div style={{ fontSize: "12px", color: "#64748b" }}>
                        {course.enrolledCount || 128} students • {course.totalLessons || 12} lessons • {course.totalQuizzes || 8} quizzes
                      </div>
                    </div>
                    <span
                      style={{
                        fontSize: "11px",
                        fontWeight: "800",
                        padding: "2px 8px",
                        borderRadius: "999px",
                        background: "#dcfce7",
                        color: "#16a34a",
                      }}
                    >
                      Active
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div style={{ display: "flex", alignItems: "center", gap: "10px", marginTop: "10px" }}>
                    <div style={{ flex: 1, height: "6px", background: "#e2e8f0", borderRadius: "999px", overflow: "hidden" }}>
                      <div
                        style={{
                          width: `${course.completionRate || course.progressPercentage || 72}%`,
                          height: "100%",
                          background: "#10b981",
                          borderRadius: "999px",
                        }}
                      />
                    </div>
                    <span style={{ fontSize: "12px", fontWeight: "700", color: "#0c211d" }}>
                      {course.completionRate || course.progressPercentage || 72}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </TrainerShell>
  );
}
