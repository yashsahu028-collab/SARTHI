"use client";

import React, { useState, useMemo, useEffect } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import TrainerShell from "@/components/trainer/TrainerShell";
import { useTrainer } from "@/lib/services/TrainerContext";

export default function TrainerAssignmentsPage() {
  const searchParams = useSearchParams();
  const filterParam = searchParams?.get("filter");
  const reviewIdParam = searchParams?.get("reviewId");

  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState(filterParam === "pending" ? "pending" : "all"); // 'all' | 'pending' | 'reviewed' | 'late' | 'missing'
  const [selectedAssignmentId, setSelectedAssignmentId] = useState("all");
  const [activeSubmissionForGrading, setActiveSubmissionForGrading] = useState(null);

  const { assignments, submissions, courses, gradeSubmission, setActiveModal } = useTrainer();

  // Grading form state
  const [gradeMarks, setGradeMarks] = useState("");
  const [gradeFeedback, setGradeFeedback] = useState("");
  const [isSavingGrade, setIsSavingGrade] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 2500);
  };

  // Sync with URL reviewId
  useEffect(() => {
    if (reviewIdParam) {
      const target = (submissions || []).find((s) => s.id === reviewIdParam);
      if (target) {
        openGradingPanel(target);
      }
    }
  }, [reviewIdParam, submissions]);

  // Primary active assignment for Overview section (Section 13)
  const activeAssignment = useMemo(() => {
    if (selectedAssignmentId !== "all") {
      return (assignments || []).find((a) => a.id === selectedAssignmentId) || (assignments || [])[0];
    }
    return (
      (assignments || [])[0] || {
        id: "asg-quad-eq",
        title: "Quadratic Equations — Worksheet",
        class: "Class 10 A",
        dueDate: "Sept 10, 2026",
        totalSubmissions: 28,
        totalExpected: 35,
        gradedCount: 20,
        pendingCount: 8,
      }
    );
  }, [assignments, selectedAssignmentId]);

  // Filtered submissions list
  const filteredSubmissions = useMemo(() => {
    return (submissions || []).filter((sub) => {
      // Status filter
      let matchStatus = true;
      if (statusFilter === "pending") matchStatus = sub.status === "pending";
      else if (statusFilter === "reviewed") matchStatus = sub.status === "graded";
      else if (statusFilter === "late") matchStatus = sub.status === "late";
      else if (statusFilter === "missing") matchStatus = sub.status === "missing";

      // Assignment filter
      const matchAssignment = selectedAssignmentId === "all" || sub.assignmentId === selectedAssignmentId;

      // Search filter
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        (sub.studentName && sub.studentName.toLowerCase().includes(q)) ||
        (sub.assignmentTitle && sub.assignmentTitle.toLowerCase().includes(q)) ||
        (sub.class && sub.class.toLowerCase().includes(q));

      return matchStatus && matchAssignment && matchSearch;
    });
  }, [submissions, statusFilter, selectedAssignmentId, searchQuery]);

  const pendingCountTotal = (submissions || []).filter((s) => s.status === "pending").length;
  const gradedCountTotal = (submissions || []).filter((s) => s.status === "graded").length;

  const openGradingPanel = (submission) => {
    setActiveSubmissionForGrading(submission);
    setGradeMarks(submission.score !== null && submission.score !== undefined ? String(submission.score) : "18");
    setGradeFeedback(submission.feedback || "Great work! Clear mathematical reasoning throughout.");
  };

  const closeGradingPanel = () => {
    setActiveSubmissionForGrading(null);
  };

  const handleSaveGrade = async (e) => {
    e.preventDefault();
    if (!activeSubmissionForGrading) return;
    setIsSavingGrade(true);

    await gradeSubmission(activeSubmissionForGrading.id, {
      score: Number(gradeMarks),
      feedback: gradeFeedback,
    });

    setIsSavingGrade(false);
    showToast(`✓ Assignment graded for ${activeSubmissionForGrading.studentName}!`);
    closeGradingPanel();
  };

  return (
    <TrainerShell searchQuery={searchQuery} setSearchQuery={setSearchQuery} placeholder="Search student name, assignment, or class...">
      <div style={{ padding: "28px 36px 64px 36px", maxWidth: "1360px", margin: "0 auto", width: "100%" }}>
        {/* Toast Alert */}
        {toastMessage && (
          <div
            style={{
              position: "fixed",
              bottom: "24px",
              right: "24px",
              background: "#0c211d",
              color: "#ffffff",
              padding: "12px 20px",
              borderRadius: "12px",
              boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
              fontSize: "13.5px",
              fontWeight: "700",
              zIndex: 9999,
            }}
          >
            {toastMessage}
          </div>
        )}

        {/* Page Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "28px", flexWrap: "wrap", gap: "16px" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
              <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#10b981" }} />
              <span style={{ fontSize: "11px", fontWeight: "800", color: "#065f46", letterSpacing: "0.12em", textTransform: "uppercase" }}>
                ACADEMIC EVALUATION DESK
              </span>
            </div>
            <h1 style={{ fontSize: "30px", fontWeight: "800", color: "#0a2920", margin: "0 0 6px 0", letterSpacing: "-0.5px" }}>
              Assignment Grading Desk
            </h1>
            <p style={{ fontSize: "14px", color: "#64748b", margin: 0 }}>
              Evaluate student worksheets, inspect mathematical solutions, assign marks with rubric feedback, and track submission completion.
            </p>
          </div>

          <button
            type="button"
            className="db-btn-primary"
            onClick={() => setActiveModal({ type: "new_assignment", data: null })}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              padding: "10px 20px",
              borderRadius: "12px",
              background: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
              color: "#ffffff",
              fontSize: "13.5px",
              fontWeight: "700",
              border: "none",
              cursor: "pointer",
              boxShadow: "0 4px 12px rgba(5, 150, 105, 0.25)",
            }}
          >
            <span style={{ fontSize: "16px", fontWeight: "900", lineHeight: "1" }}>+</span>
            <span>Create Assignment</span>
          </button>
        </div>

        {/* ==========================================================================
            1. ASSIGNMENT OVERVIEW CARD (Section 13)
            ========================================================================== */}
        <div
          style={{
            background: "#ffffff",
            border: "1px solid var(--sarthi-border, #e8f0eb)",
            borderRadius: "20px",
            padding: "24px",
            marginBottom: "28px",
            boxShadow: "0 1px 3px rgba(0, 0, 0, 0.02)",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "16px", marginBottom: "20px" }}>
            <div>
              <span style={{ fontSize: "11px", fontWeight: "800", color: "#059669", textTransform: "uppercase", letterSpacing: "0.08em" }}>
                ACTIVE ASSIGNMENT OVERVIEW
              </span>
              <h2 style={{ fontSize: "20px", fontWeight: "800", color: "#0c211d", margin: "4px 0" }}>
                {activeAssignment.title}
              </h2>
              <div style={{ display: "flex", alignItems: "center", gap: "12px", fontSize: "13px", color: "#64748b" }}>
                <span>👥 {activeAssignment.class || "Class 10 A"}</span>
                <span>•</span>
                <span>📅 Due: {activeAssignment.dueDate || "Sept 10, 2026"}</span>
              </div>
            </div>

            {/* Assignment Selector if multiple */}
            {assignments.length > 1 && (
              <select
                value={selectedAssignmentId}
                onChange={(e) => setSelectedAssignmentId(e.target.value)}
                style={{
                  padding: "8px 14px",
                  borderRadius: "10px",
                  border: "1px solid #cbd5e1",
                  fontSize: "13px",
                  fontWeight: "600",
                  background: "#fff",
                  outline: "none",
                }}
              >
                <option value="all">All Assignments</option>
                {assignments.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.title}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* 3 Metric Progress Pills (Section 13) */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
              gap: "14px",
            }}
          >
            <div style={{ background: "#f8faf9", border: "1px solid #e2e8f0", padding: "14px 18px", borderRadius: "14px" }}>
              <div style={{ fontSize: "11.5px", fontWeight: "700", color: "#64748b", textTransform: "uppercase" }}>Submissions</div>
              <div style={{ fontSize: "24px", fontWeight: "800", color: "#0c211d", marginTop: "2px" }}>
                {activeAssignment.totalSubmissions || 28} <span style={{ fontSize: "14px", color: "#94a3b8" }}>/ {activeAssignment.totalExpected || 35}</span>
              </div>
            </div>

            <div style={{ background: "#ecfdf5", border: "1px solid #bbf7d0", padding: "14px 18px", borderRadius: "14px" }}>
              <div style={{ fontSize: "11.5px", fontWeight: "700", color: "#065f46", textTransform: "uppercase" }}>Reviewed</div>
              <div style={{ fontSize: "24px", fontWeight: "800", color: "#059669", marginTop: "2px" }}>
                {activeAssignment.gradedCount || 20}
              </div>
            </div>

            <div style={{ background: "#fef3c7", border: "1px solid #fde68a", padding: "14px 18px", borderRadius: "14px" }}>
              <div style={{ fontSize: "11.5px", fontWeight: "700", color: "#92400e", textTransform: "uppercase" }}>Pending</div>
              <div style={{ fontSize: "24px", fontWeight: "800", color: "#d97706", marginTop: "2px" }}>
                {activeAssignment.pendingCount || 8}
              </div>
            </div>
          </div>
        </div>

        {/* ==========================================================================
            2. SUBMISSIONS TABLE & FILTER CONTROLS (Section 14)
            ========================================================================== */}
        <div style={{ background: "#ffffff", border: "1px solid var(--sarthi-border, #e8f0eb)", borderRadius: "20px", padding: "20px", boxShadow: "0 1px 3px rgba(0, 0, 0, 0.02)" }}>
          {/* Controls Bar: Filter Pills + Search Student */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "18px", flexWrap: "wrap", gap: "12px" }}>
            {/* Filter Pills */}
            <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
              {[
                { id: "all", label: "All" },
                { id: "pending", label: `Pending (${pendingCountTotal})` },
                { id: "reviewed", label: `Reviewed (${gradedCountTotal})` },
                { id: "late", label: "Late" },
                { id: "missing", label: "Missing" },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setStatusFilter(f.id)}
                  style={{
                    border: "none",
                    padding: "7px 14px",
                    borderRadius: "8px",
                    fontSize: "12.5px",
                    fontWeight: "700",
                    cursor: "pointer",
                    background: statusFilter === f.id ? "#059669" : "#f1f5f9",
                    color: statusFilter === f.id ? "#ffffff" : "#475569",
                    transition: "all 0.15s ease",
                  }}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Quick Student Search */}
            <div style={{ position: "relative", minWidth: "220px" }}>
              <input
                type="text"
                placeholder="Search student..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  width: "100%",
                  padding: "8px 12px 8px 32px",
                  borderRadius: "999px",
                  border: "1px solid #cbd5e1",
                  fontSize: "12.5px",
                  outline: "none",
                }}
              />
              <span style={{ position: "absolute", left: "10px", top: "50%", transform: "translateY(-50%)", fontSize: "12px", color: "#94a3b8" }}>
                🔍
              </span>
            </div>
          </div>

          {/* Submissions Table */}
          {filteredSubmissions.length === 0 ? (
            <div style={{ textAlign: "center", padding: "40px 20px" }}>
              <div style={{ fontSize: "32px", marginBottom: "8px" }}>🎉</div>
              <h3 style={{ fontSize: "16px", fontWeight: "700", color: "#0c211d", margin: "0 0 4px 0" }}>
                You&apos;re all caught up!
              </h3>
              <p style={{ fontSize: "13px", color: "#64748b", margin: 0 }}>
                No submissions matching this filter.
              </p>
            </div>
          ) : (
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "13px" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid #e2e8f0", background: "#f8faf9" }}>
                    <th style={{ padding: "12px 14px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase" }}>Student</th>
                    <th style={{ padding: "12px 14px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase" }}>Submitted</th>
                    <th style={{ padding: "12px 14px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase" }}>Status</th>
                    <th style={{ padding: "12px 14px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase" }}>Marks</th>
                    <th style={{ padding: "12px 14px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase" }}>Feedback</th>
                    <th style={{ padding: "12px 14px", fontWeight: "800", color: "#475569", fontSize: "11.5px", textTransform: "uppercase", textAlign: "right" }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSubmissions.map((sub) => {
                    const isGraded = sub.status === "graded";
                    return (
                      <tr key={sub.id} style={{ borderBottom: "1px solid #f1f5f9", transition: "background 0.15s ease" }}>
                        <td style={{ padding: "12px 14px" }}>
                          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <img
                              src={sub.studentAvatar || "/images/student-img-1.jpg"}
                              alt={sub.studentName}
                              style={{ width: "32px", height: "32px", borderRadius: "50%", objectFit: "cover" }}
                            />
                            <div>
                              <div style={{ fontWeight: "700", color: "#0c211d" }}>{sub.studentName}</div>
                              <div style={{ fontSize: "11.5px", color: "#64748b" }}>{sub.class || "Class 10 A"}</div>
                            </div>
                          </div>
                        </td>

                        <td style={{ padding: "12px 14px", color: "#64748b" }}>
                          {sub.submittedFormatted || "Sep 8, 4:12 PM"}
                        </td>

                        <td style={{ padding: "12px 14px" }}>
                          <span
                            style={{
                              fontSize: "11.5px",
                              fontWeight: "800",
                              padding: "3px 9px",
                              borderRadius: "999px",
                              background: isGraded ? "#dcfce7" : "#fee2e2",
                              color: isGraded ? "#166534" : "#991b1b",
                            }}
                          >
                            {isGraded ? "Graded" : "Submitted"}
                          </span>
                        </td>

                        <td style={{ padding: "12px 14px", fontWeight: "700", color: "#0c211d" }}>
                          {isGraded ? `${sub.score}/${sub.maxScore || 20}` : "—"}
                        </td>

                        <td style={{ padding: "12px 14px", color: "#475569", maxWidth: "240px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {sub.feedback ? sub.feedback : "—"}
                        </td>

                        <td style={{ padding: "12px 14px", textAlign: "right" }}>
                          <button
                            type="button"
                            onClick={() => openGradingPanel(sub)}
                            style={{
                              padding: "6px 14px",
                              borderRadius: "8px",
                              background: isGraded ? "#f1f5f9" : "#059669",
                              color: isGraded ? "#0c211d" : "#ffffff",
                              border: isGraded ? "1px solid #cbd5e1" : "none",
                              fontSize: "12px",
                              fontWeight: "700",
                              cursor: "pointer",
                            }}
                          >
                            {isGraded ? "View / Edit" : "Review"}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* ==========================================================================
            3. DEDICATED GRADING SIDE PANEL / DRAWER (Section 15)
            ========================================================================== */}
        {activeSubmissionForGrading && (
          <>
            <div className="side-drawer-backdrop" onClick={closeGradingPanel} />

            <div className="side-drawer-panel" style={{ padding: "28px" }}>
              {/* Drawer Top Header */}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px", paddingBottom: "16px", borderBottom: "1px solid #e2e8f0" }}>
                <div>
                  <span style={{ fontSize: "11px", fontWeight: "800", color: "#059669", textTransform: "uppercase" }}>
                    STUDENT SUBMISSION EVALUATION
                  </span>
                  <h3 style={{ fontSize: "18px", fontWeight: "800", color: "#0c211d", margin: "4px 0 0 0" }}>
                    {activeSubmissionForGrading.assignmentTitle}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={closeGradingPanel}
                  style={{ background: "none", border: "none", fontSize: "20px", cursor: "pointer", color: "#94a3b8" }}
                >
                  ✕
                </button>
              </div>

              {/* Student Info Card */}
              <div style={{ display: "flex", alignItems: "center", gap: "12px", background: "#f8faf9", padding: "14px", borderRadius: "14px", marginBottom: "20px" }}>
                <img
                  src={activeSubmissionForGrading.studentAvatar || "/images/student-img-1.jpg"}
                  alt={activeSubmissionForGrading.studentName}
                  style={{ width: "42px", height: "42px", borderRadius: "50%", objectFit: "cover" }}
                />
                <div>
                  <div style={{ fontSize: "14.5px", fontWeight: "700", color: "#0c211d" }}>
                    {activeSubmissionForGrading.studentName}
                  </div>
                  <div style={{ fontSize: "12px", color: "#64748b" }}>
                    {activeSubmissionForGrading.class || "Class 10 A"} • Submitted {activeSubmissionForGrading.submittedFormatted || "Today"}
                  </div>
                </div>
              </div>

              {/* Submitted Work Content Area (Section 15) */}
              <div style={{ marginBottom: "24px" }}>
                <label style={{ display: "block", fontSize: "12px", fontWeight: "800", color: "#64748b", textTransform: "uppercase", marginBottom: "8px" }}>
                  Submitted Answer & Work
                </label>
                <div
                  style={{
                    background: "#f1f5f9",
                    padding: "16px",
                    borderRadius: "12px",
                    fontSize: "13.5px",
                    lineHeight: "1.5",
                    color: "#0c211d",
                    whiteSpace: "pre-wrap",
                    border: "1px solid #e2e8f0",
                  }}
                >
                  {activeSubmissionForGrading.content || "Solved 10 quadratic problems using discriminant method. Steps verified with substitution."}
                </div>

                {activeSubmissionForGrading.fileName && (
                  <div style={{ marginTop: "10px", display: "flex", alignItems: "center", gap: "8px", background: "#ecfdf5", padding: "8px 12px", borderRadius: "8px", border: "1px solid #bbf7d0" }}>
                    <span>📄</span>
                    <span style={{ fontSize: "12.5px", fontWeight: "600", color: "#065f46" }}>
                      {activeSubmissionForGrading.fileName}
                    </span>
                    <span style={{ marginLeft: "auto", fontSize: "11px", color: "#059669", fontWeight: "700", cursor: "pointer" }}>
                      Preview Document ↗
                    </span>
                  </div>
                )}
              </div>

              {/* Grading Inputs Form */}
              <form onSubmit={handleSaveGrade} style={{ display: "flex", flexDirection: "column", gap: "16px", marginTop: "auto" }}>
                <div>
                  <label style={{ display: "block", fontSize: "12.5px", fontWeight: "800", color: "#0c211d", marginBottom: "6px" }}>
                    Marks Awarded (Max: {activeSubmissionForGrading.maxScore || 20})
                  </label>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <input
                      type="number"
                      required
                      min={0}
                      max={activeSubmissionForGrading.maxScore || 20}
                      value={gradeMarks}
                      onChange={(e) => setGradeMarks(e.target.value)}
                      style={{
                        width: "80px",
                        padding: "10px",
                        borderRadius: "10px",
                        border: "1px solid #cbd5e1",
                        fontSize: "16px",
                        fontWeight: "800",
                        color: "#0c211d",
                        textAlign: "center",
                        outline: "none",
                      }}
                    />
                    <span style={{ fontSize: "16px", fontWeight: "700", color: "#64748b" }}>
                      / {activeSubmissionForGrading.maxScore || 20}
                    </span>
                  </div>
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "12.5px", fontWeight: "800", color: "#0c211d", marginBottom: "6px" }}>
                    Teacher Feedback & Comments
                  </label>
                  <textarea
                    rows={4}
                    value={gradeFeedback}
                    onChange={(e) => setGradeFeedback(e.target.value)}
                    placeholder="Provide constructive academic evaluation..."
                    style={{
                      width: "100%",
                      padding: "10px 14px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "13.5px",
                      outline: "none",
                      resize: "vertical",
                    }}
                  />
                </div>

                {/* Feedback Quick-Preset Chips */}
                <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                  {[
                    "Great work! 🌟",
                    "Clear reasoning, check calculations",
                    "Please show formula steps",
                    "Excellent explanation of roots",
                  ].map((chip) => (
                    <button
                      key={chip}
                      type="button"
                      onClick={() => setGradeFeedback((prev) => (prev ? `${prev} ${chip}` : chip))}
                      style={{
                        background: "#f1f5f9",
                        border: "1px solid #e2e8f0",
                        padding: "4px 10px",
                        borderRadius: "999px",
                        fontSize: "11px",
                        color: "#334155",
                        cursor: "pointer",
                        fontWeight: "600",
                      }}
                    >
                      + {chip}
                    </button>
                  ))}
                </div>

                {/* Save Grade Button */}
                <div style={{ display: "flex", gap: "10px", marginTop: "12px" }}>
                  <button
                    type="submit"
                    disabled={isSavingGrade}
                    className="db-btn-primary"
                    style={{
                      flex: 1,
                      padding: "12px",
                      borderRadius: "10px",
                      background: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
                      color: "#ffffff",
                      fontSize: "13.5px",
                      fontWeight: "700",
                      border: "none",
                      cursor: "pointer",
                    }}
                  >
                    {isSavingGrade ? "Saving Grade..." : "Save & Update Grade"}
                  </button>

                  <button
                    type="button"
                    onClick={closeGradingPanel}
                    style={{
                      padding: "12px 18px",
                      borderRadius: "10px",
                      background: "#f1f5f9",
                      border: "none",
                      color: "#475569",
                      fontSize: "13.5px",
                      fontWeight: "700",
                      cursor: "pointer",
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </>
        )}
      </div>
    </TrainerShell>
  );
}
