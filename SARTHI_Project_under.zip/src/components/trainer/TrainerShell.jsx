"use client";

import React from "react";
import TrainerSidebar from "./TrainerSidebar";
import TrainerHeader from "./TrainerHeader";
import "@/app/dashboard/dashboard.css";
import "@/app/trainer/trainer.css";

export default function TrainerShell({
  children,
  searchQuery,
  setSearchQuery,
  placeholder = "Search courses, students, quizzes, or assignments...",
}) {
  return (
    <div className="sarthi-dashboard-root">
      {/* Fixed Left Sidebar / Mobile Drawer */}
      <TrainerSidebar />

      {/* Main Content Area */}
      <main className="db-main-content">
        <TrainerHeader
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          placeholder={placeholder}
        />
        {children}
      </main>
    </div>
  );
}
