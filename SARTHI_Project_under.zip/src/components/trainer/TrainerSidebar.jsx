"use client";

import React from "react";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { useTrainer } from "@/lib/services/TrainerContext";

export default function TrainerSidebar() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const currentTab = searchParams?.get("tab");
  const { trainer, submissions, certificates, mobileSidebarOpen, setMobileSidebarOpen } = useTrainer();

  const pendingSubmissionsCount = (submissions || []).filter((s) => s.status === "pending").length;

  const closeDrawer = () => {
    if (setMobileSidebarOpen) setMobileSidebarOpen(false);
  };

  const navGroups = [
    {
      label: null,
      items: [
        {
          name: "Dashboard",
          href: "/trainer",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect width="7" height="9" x="3" y="3" rx="1" />
              <rect width="7" height="5" x="14" y="3" rx="1" />
              <rect width="7" height="9" x="14" y="12" rx="1" />
              <rect width="7" height="5" x="3" y="16" rx="1" />
            </svg>
          ),
        },
      ],
    },
    {
      label: "TEACHING",
      items: [
        {
          name: "Courses",
          href: "/trainer/courses",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
              <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
            </svg>
          ),
        },
        {
          name: "Students",
          href: "/trainer/students",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
              <circle cx="9" cy="7" r="4"></circle>
              <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
              <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
            </svg>
          ),
        },
        {
          name: "Live Classes",
          href: "/trainer/live",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="23 7 16 12 23 17 23 7"></polygon>
              <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
            </svg>
          ),
        },
        {
          name: "Calendar",
          href: "/trainer/live?tab=calendar",
          isActiveOverride: pathname === "/trainer/live" && currentTab === "calendar",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect width="18" height="18" x="3" y="4" rx="2" ry="2"></rect>
              <line x1="16" x2="16" y1="2" y2="6"></line>
              <line x1="8" x2="8" y1="2" y2="6"></line>
              <line x1="3" x2="21" y1="10" y2="10"></line>
            </svg>
          ),
        },
      ],
    },
    {
      label: "CONTENT",
      items: [
        {
          name: "Quizzes",
          href: "/trainer/quiz",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
          ),
        },
        {
          name: "Assignments",
          href: "/trainer/assignments",
          badge: pendingSubmissionsCount > 0 ? pendingSubmissionsCount : null,
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
              <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
              <line x1="9" y1="12" x2="15" y2="12"></line>
              <line x1="9" y1="16" x2="13" y2="16"></line>
            </svg>
          ),
        },
      ],
    },
    {
      label: "CLASSROOM",
      items: [
        {
          name: "Attendance",
          href: "/trainer/attendance",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 11l3 3L22 4"></path>
              <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
            </svg>
          ),
        },
        {
          name: "Performance",
          href: "/trainer/analytics",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="20" x2="18" y2="10"></line>
              <line x1="12" y1="20" x2="12" y2="4"></line>
              <line x1="6" y1="20" x2="6" y2="14"></line>
            </svg>
          ),
        },
      ],
    },
    {
      label: null,
      divider: true,
      items: [
        {
          name: "Settings",
          href: "/trainer/settings",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="3"></circle>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
            </svg>
          ),
        },
        {
          name: "Help & Support",
          href: "/trainer/messages",
          icon: (
            <svg className="db-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
          ),
        },
      ],
    },
  ];

  return (
    <>
      {/* Mobile Drawer Backdrop */}
      {mobileSidebarOpen && (
        <div
          className="db-sidebar-backdrop"
          onClick={closeDrawer}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(10, 41, 32, 0.4)",
            backdropFilter: "blur(4px)",
            WebkitBackdropFilter: "blur(4px)",
            zIndex: 998,
          }}
        />
      )}

      <aside className={`db-sidebar ${mobileSidebarOpen ? "open-mobile" : ""}`}>
        <div>
          {/* Logo Branding */}
          <div
            className="db-sidebar-brand"
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              paddingBottom: "16px",
              marginBottom: "8px",
            }}
          >
            <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
              <Link href="/trainer" onClick={closeDrawer} title="SARTHI Teacher Studio">
                <img
                  src="/images/sarthi-logo-forest.png"
                  alt="SARTHI Logo"
                  className="db-brand-logo"
                  style={{ height: "36px", objectFit: "contain" }}
                />
              </Link>
              <span
                style={{
                  fontSize: "9.5px",
                  fontWeight: "800",
                  color: "#059669",
                  letterSpacing: "0.14em",
                  textTransform: "uppercase",
                  paddingLeft: "2px",
                }}
              >
                Teacher Studio
              </span>
            </div>

            {/* Mobile Close Button */}
            <button
              type="button"
              className="db-sidebar-close-btn"
              onClick={closeDrawer}
              aria-label="Close Navigation"
              style={{
                background: "transparent",
                border: "none",
                color: "#64748b",
                cursor: "pointer",
                padding: "6px",
                display: "none",
              }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>

          {/* Hierarchical Navigation Menu */}
          <div className="db-nav-scroll-wrap" style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            {navGroups.map((group, gIdx) => (
              <div key={group.label || `grp-${gIdx}`}>
                {group.divider && (
                  <hr
                    style={{
                      border: "none",
                      borderTop: "1px solid var(--sarthi-border, #e8f0eb)",
                      margin: "8px 0 12px 0",
                    }}
                  />
                )}

                {group.label && (
                  <div
                    style={{
                      fontSize: "10px",
                      fontWeight: "800",
                      color: "#94a3b8",
                      letterSpacing: "0.12em",
                      padding: "4px 12px",
                      textTransform: "uppercase",
                    }}
                  >
                    {group.label}
                  </div>
                )}

                <ul className="db-nav-menu" style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "3px" }}>
                  {group.items.map((item) => {
                    const isActive =
                      item.isActiveOverride !== undefined
                        ? item.isActiveOverride
                        : item.href === "/trainer"
                        ? pathname === "/trainer"
                        : pathname === item.href || (pathname.startsWith(item.href) && !item.href.includes("?"));

                    return (
                      <li key={item.name} className="db-nav-item">
                        <Link
                          href={item.href}
                          onClick={closeDrawer}
                          className={`db-nav-btn ${isActive ? "active" : ""}`}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "10px",
                            padding: "9px 12px",
                            borderRadius: "10px",
                            fontSize: "13px",
                            fontWeight: isActive ? "700" : "600",
                            color: isActive ? "#ffffff" : "#475569",
                            background: isActive ? "linear-gradient(135deg, #059669 0%, #10b981 100%)" : "transparent",
                            textDecoration: "none",
                            transition: "all 0.15s ease",
                          }}
                        >
                          <span style={{ display: "flex", alignItems: "center", width: "18px", height: "18px", color: isActive ? "#ffffff" : "#64748b" }}>
                            {item.icon}
                          </span>
                          <span style={{ flex: 1 }}>{item.name}</span>
                          {item.badge && (
                            <span
                              style={{
                                background: isActive ? "rgba(255, 255, 255, 0.3)" : "#10b981",
                                color: "#ffffff",
                                fontSize: "11px",
                                fontWeight: "800",
                                padding: "2px 7px",
                                borderRadius: "999px",
                              }}
                            >
                              {item.badge}
                            </span>
                          )}
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Area: Faculty Profile Pill */}
        <div
          className="db-sidebar-bottom-area"
          style={{
            borderTop: "1px solid var(--sarthi-border-light, #e8f0eb)",
            paddingTop: "12px",
            marginTop: "16px",
          }}
        >
          <Link
            href="/trainer/settings"
            onClick={closeDrawer}
            className="db-sidebar-user-pill"
            style={{
              textDecoration: "none",
              display: "flex",
              alignItems: "center",
              gap: "10px",
              padding: "6px 8px",
              borderRadius: "12px",
              transition: "background 0.2s ease",
            }}
          >
            <div className="db-user-avatar-wrap" style={{ position: "relative" }}>
              <img
                src={trainer.avatar || "/images/student-img-1.jpg"}
                alt={trainer.name}
                className="db-user-avatar"
                style={{
                  width: "36px",
                  height: "36px",
                  borderRadius: "50%",
                  objectFit: "cover",
                  border: "2px solid #10b981",
                }}
              />
              <span
                style={{
                  position: "absolute",
                  bottom: "0",
                  right: "0",
                  width: "9px",
                  height: "9px",
                  borderRadius: "50%",
                  background: "#10b981",
                  border: "1.5px solid #ffffff",
                }}
              />
            </div>
            <div className="db-user-info-text" style={{ flex: 1, minWidth: 0 }}>
              <div
                className="db-user-name"
                style={{
                  fontSize: "13px",
                  fontWeight: "700",
                  color: "#0c211d",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                {trainer.name}
              </div>
              <div
                className="db-user-role"
                style={{
                  fontSize: "11px",
                  color: "#64748b",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                }}
              >
                {trainer.title || "Teacher & Lead Faculty"}
              </div>
            </div>
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#94a3b8" strokeWidth="2">
              <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
          </Link>
        </div>
      </aside>
    </>
  );
}
