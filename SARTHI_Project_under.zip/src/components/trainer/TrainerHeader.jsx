"use client";

import React, { useState, useRef, useEffect, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useTrainer } from "@/lib/services/TrainerContext";

export default function TrainerHeader({
  searchQuery = "",
  setSearchQuery = () => {},
  placeholder = "Search courses, students, quizzes, or assignments...",
}) {
  const router = useRouter();
  const {
    trainer,
    courses,
    trainees,
    submissions,
    liveClasses,
    setActiveModal,
    toggleMobileSidebar,
  } = useTrainer();

  const [internalQuery, setInternalQuery] = useState(searchQuery);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showCreateMenu, setShowCreateMenu] = useState(false);

  const searchInputRef = useRef(null);
  const searchContainerRef = useRef(null);
  const notifRef = useRef(null);
  const userMenuRef = useRef(null);
  const createMenuRef = useRef(null);

  // Sync internal query
  useEffect(() => {
    setInternalQuery(searchQuery);
  }, [searchQuery]);

  // Click outside listener
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target)) {
        setIsSearchOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setShowNotifications(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setShowUserMenu(false);
      }
      if (createMenuRef.current && !createMenuRef.current.contains(e.target)) {
        setShowCreateMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleQueryChange = (e) => {
    const val = e.target.value;
    setInternalQuery(val);
    setSearchQuery(val);
    setIsSearchOpen(val.trim().length > 0);
  };

  // Search Results
  const searchResults = useMemo(() => {
    const q = (internalQuery || "").trim().toLowerCase();
    if (!q) return { courses: [], trainees: [], submissions: [], total: 0 };

    const matchedCourses = (courses || []).filter((c) =>
      c.title.toLowerCase().includes(q) || c.category.toLowerCase().includes(q)
    );

    const matchedTrainees = (trainees || []).filter((t) =>
      t.name.toLowerCase().includes(q) || (t.division && t.division.toLowerCase().includes(q))
    );

    const matchedSubmissions = (submissions || []).filter((s) =>
      s.studentName.toLowerCase().includes(q) || s.assignmentTitle.toLowerCase().includes(q)
    );

    return {
      courses: matchedCourses.slice(0, 3),
      trainees: matchedTrainees.slice(0, 3),
      submissions: matchedSubmissions.slice(0, 3),
      total: matchedCourses.length + matchedTrainees.length + matchedSubmissions.length,
    };
  }, [internalQuery, courses, trainees, submissions]);

  // Notifications
  const notifications = [
    {
      id: 1,
      title: "New Assignment Submitted",
      desc: "Aarav Sharma submitted Quadratic Equations — Worksheet.",
      time: "15 mins ago",
      unread: true,
      link: "/trainer/assignments",
    },
    {
      id: 2,
      title: "Live Class Starting Soon",
      desc: "Mathematics — Algebra session starts at 4:00 PM today.",
      time: "35 mins ago",
      unread: true,
      link: "/trainer/live",
    },
    {
      id: 3,
      title: "Attendance Report Ready",
      desc: "Class 10 Section A attendance compiled: 92% present rate.",
      time: "2 hours ago",
      unread: false,
      link: "/trainer/attendance",
    },
  ];

  const unreadCount = notifications.filter((n) => n.unread).length;

  // Format today's date
  const todayFormatted = useMemo(() => {
    const now = new Date();
    return now.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  }, []);

  return (
    <header className="db-topbar">
      {/* Left Area: Mobile Hamburger + Live Search Bar */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px", flex: 1, minWidth: 0 }}>
        {/* Mobile Hamburger Toggle */}
        <button
          type="button"
          className="db-mobile-nav-toggle"
          onClick={toggleMobileSidebar}
          aria-label="Open Navigation Menu"
          style={{
            display: "none",
            alignItems: "center",
            justifyContent: "center",
            width: "38px",
            height: "38px",
            borderRadius: "10px",
            background: "var(--sarthi-surface-subtle, #fcfdfc)",
            border: "1px solid var(--sarthi-border, #e8f0eb)",
            color: "var(--sarthi-text-heading, #0c211d)",
            cursor: "pointer",
            flexShrink: 0,
          }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
          </svg>
        </button>

        {/* Live Search Input Bar */}
        <div className="db-search-bar-wrap" ref={searchContainerRef} style={{ flex: 1, maxWidth: "540px" }}>
          <div className="db-search-bar">
            <svg
              className="db-search-icon"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
            <input
              ref={searchInputRef}
              type="text"
              className="db-search-input"
              placeholder={placeholder}
              value={internalQuery}
              onChange={handleQueryChange}
              onFocus={() => {
                if (internalQuery.trim().length > 0) setIsSearchOpen(true);
              }}
            />
            {internalQuery ? (
              <button
                onClick={() => {
                  setInternalQuery("");
                  setSearchQuery("");
                  setIsSearchOpen(false);
                }}
                style={{
                  background: "none",
                  border: "none",
                  color: "#94a3b8",
                  cursor: "pointer",
                  padding: "2px",
                  display: "flex",
                }}
                title="Clear search"
              >
                ✕
              </button>
            ) : (
              <span className="db-search-shortcut" style={{ fontSize: "11px", color: "#94a3b8", paddingRight: "8px" }}>
                ⌘ K
              </span>
            )}
          </div>

          {/* Live Search Results Dropdown */}
          {isSearchOpen && (
            <div className="db-search-dropdown" style={{ zIndex: 100 }}>
              {searchResults.total === 0 ? (
                <div className="db-search-empty" style={{ padding: "16px", textAlign: "center" }}>
                  <p style={{ margin: 0, fontWeight: "600", fontSize: "13px", color: "#0c211d" }}>
                    No results found for &ldquo;{internalQuery}&rdquo;
                  </p>
                  <p style={{ margin: "4px 0 0 0", fontSize: "12px", color: "#64748b" }}>
                    Try searching for courses, students, or assignments.
                  </p>
                </div>
              ) : (
                <div className="db-search-results-list" style={{ maxHeight: "360px", overflowY: "auto" }}>
                  {searchResults.courses.length > 0 && (
                    <div className="db-search-group" style={{ padding: "8px 12px" }}>
                      <span style={{ fontSize: "10.5px", fontWeight: "800", color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.08em" }}>
                        Courses
                      </span>
                      {searchResults.courses.map((c) => (
                        <Link
                          key={c.id}
                          href="/trainer/courses"
                          onClick={() => setIsSearchOpen(false)}
                          style={{
                            display: "block",
                            padding: "8px 10px",
                            borderRadius: "8px",
                            textDecoration: "none",
                            color: "inherit",
                          }}
                        >
                          <div style={{ fontSize: "13px", fontWeight: "700", color: "#0c211d" }}>📚 {c.title}</div>
                          <div style={{ fontSize: "11.5px", color: "#64748b" }}>{c.category} • {c.enrolledCount || 0} students</div>
                        </Link>
                      ))}
                    </div>
                  )}

                  {searchResults.trainees.length > 0 && (
                    <div className="db-search-group" style={{ padding: "8px 12px" }}>
                      <span style={{ fontSize: "10.5px", fontWeight: "800", color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.08em" }}>
                        Students
                      </span>
                      {searchResults.trainees.map((t) => (
                        <Link
                          key={t.id}
                          href="/trainer/students"
                          onClick={() => setIsSearchOpen(false)}
                          style={{
                            display: "block",
                            padding: "8px 10px",
                            borderRadius: "8px",
                            textDecoration: "none",
                            color: "inherit",
                          }}
                        >
                          <div style={{ fontSize: "13px", fontWeight: "700", color: "#0c211d" }}>👤 {t.name}</div>
                          <div style={{ fontSize: "11.5px", color: "#64748b" }}>{t.division || t.class} • {t.attendance || 90}% Attendance</div>
                        </Link>
                      ))}
                    </div>
                  )}

                  {searchResults.submissions.length > 0 && (
                    <div className="db-search-group" style={{ padding: "8px 12px" }}>
                      <span style={{ fontSize: "10.5px", fontWeight: "800", color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.08em" }}>
                        Submissions
                      </span>
                      {searchResults.submissions.map((s) => (
                        <Link
                          key={s.id}
                          href="/trainer/assignments"
                          onClick={() => setIsSearchOpen(false)}
                          style={{
                            display: "block",
                            padding: "8px 10px",
                            borderRadius: "8px",
                            textDecoration: "none",
                            color: "inherit",
                          }}
                        >
                          <div style={{ fontSize: "13px", fontWeight: "700", color: "#0c211d" }}>📝 {s.studentName}</div>
                          <div style={{ fontSize: "11.5px", color: "#64748b" }}>{s.assignmentTitle} • {s.status}</div>
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Topbar Right Actions: Date chip + "+ Create Session" + Notifications + Avatar */}
      <div className="db-topbar-actions" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        {/* Date Badge */}
        <div
          className="db-date-badge"
          style={{
            display: "flex",
            alignItems: "center",
            gap: "6px",
            padding: "6px 12px",
            borderRadius: "999px",
            background: "var(--sarthi-mint-50, #f0fdf4)",
            border: "1px solid var(--sarthi-mint-200, #bbf7d0)",
            color: "var(--sarthi-pine-dark, #064e3b)",
            fontSize: "12px",
            fontWeight: "700",
          }}
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
            <line x1="16" x2="16" y1="2" y2="6" />
            <line x1="8" x2="8" y1="2" y2="6" />
            <line x1="3" x2="21" y1="10" y2="10" />
          </svg>
          <span>{todayFormatted}</span>
        </div>

        {/* Quick Action: "+ Create Session" with dropdown */}
        <div style={{ position: "relative" }} ref={createMenuRef}>
          <button
            type="button"
            className="db-btn-primary"
            onClick={() => setShowCreateMenu((prev) => !prev)}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "6px",
              padding: "7px 15px",
              borderRadius: "999px",
              background: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
              color: "#ffffff",
              fontSize: "12.5px",
              fontWeight: "700",
              border: "none",
              cursor: "pointer",
              boxShadow: "0 2px 8px rgba(5, 150, 105, 0.25)",
              transition: "all 0.15s ease",
            }}
          >
            <span style={{ fontSize: "15px", fontWeight: "900", lineHeight: "1" }}>+</span>
            <span>Create Session</span>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>

          {showCreateMenu && (
            <div
              style={{
                position: "absolute",
                top: "calc(100% + 8px)",
                right: "0",
                width: "210px",
                background: "#ffffff",
                border: "1px solid var(--sarthi-border, #e8f0eb)",
                borderRadius: "14px",
                boxShadow: "0 14px 35px rgba(12, 33, 29, 0.12)",
                padding: "6px",
                zIndex: 110,
              }}
            >
              <button
                type="button"
                onClick={() => {
                  setShowCreateMenu(false);
                  router.push("/trainer/live?action=schedule");
                }}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "9px 12px",
                  borderRadius: "8px",
                  border: "none",
                  background: "transparent",
                  color: "#0c211d",
                  fontSize: "12.5px",
                  fontWeight: "600",
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                <span style={{ fontSize: "14px" }}>📹</span>
                <span>Schedule Live Class</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowCreateMenu(false);
                  router.push("/trainer/quiz?action=create");
                }}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "9px 12px",
                  borderRadius: "8px",
                  border: "none",
                  background: "transparent",
                  color: "#0c211d",
                  fontSize: "12.5px",
                  fontWeight: "600",
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                <span style={{ fontSize: "14px" }}>📝</span>
                <span>Create New Quiz</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowCreateMenu(false);
                  setActiveModal({ type: "new_assignment", data: null });
                }}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "9px 12px",
                  borderRadius: "8px",
                  border: "none",
                  background: "transparent",
                  color: "#0c211d",
                  fontSize: "12.5px",
                  fontWeight: "600",
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                <span style={{ fontSize: "14px" }}>📋</span>
                <span>New Assignment</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowCreateMenu(false);
                  router.push("/trainer/attendance");
                }}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "9px 12px",
                  borderRadius: "8px",
                  border: "none",
                  background: "transparent",
                  color: "#0c211d",
                  fontSize: "12.5px",
                  fontWeight: "600",
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                <span style={{ fontSize: "14px" }}>✅</span>
                <span>Take Attendance</span>
              </button>
            </div>
          )}
        </div>

        {/* Notification Bell Icon */}
        <div style={{ position: "relative" }} ref={notifRef}>
          <button
            type="button"
            className="db-notif-btn"
            onClick={() => setShowNotifications((prev) => !prev)}
            aria-label="View notifications"
            style={{
              position: "relative",
              width: "36px",
              height: "36px",
              borderRadius: "50%",
              background: "var(--sarthi-surface-subtle, #fcfdfc)",
              border: "1px solid var(--sarthi-border, #e8f0eb)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#475569",
              cursor: "pointer",
            }}
          >
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
            </svg>
            {unreadCount > 0 && (
              <span
                style={{
                  position: "absolute",
                  top: "2px",
                  right: "2px",
                  width: "8px",
                  height: "8px",
                  borderRadius: "50%",
                  background: "#ef4444",
                  border: "1.5px solid #ffffff",
                }}
              />
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div
              style={{
                position: "absolute",
                top: "calc(100% + 8px)",
                right: "0",
                width: "320px",
                background: "#ffffff",
                border: "1px solid var(--sarthi-border, #e8f0eb)",
                borderRadius: "16px",
                boxShadow: "0 16px 40px rgba(12, 33, 29, 0.12)",
                padding: "14px",
                zIndex: 110,
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "10px" }}>
                <span style={{ fontSize: "13px", fontWeight: "800", color: "#0c211d" }}>Notifications</span>
                <span style={{ fontSize: "11px", fontWeight: "700", color: "#059669", background: "#dcfce7", padding: "1px 6px", borderRadius: "999px" }}>
                  {unreadCount} New
                </span>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                {notifications.map((n) => (
                  <Link
                    key={n.id}
                    href={n.link}
                    onClick={() => setShowNotifications(false)}
                    style={{
                      display: "block",
                      padding: "8px 10px",
                      borderRadius: "10px",
                      background: n.unread ? "var(--sarthi-mint-50, #f0fdf4)" : "transparent",
                      textDecoration: "none",
                      border: n.unread ? "1px solid var(--sarthi-mint-200, #bbf7d0)" : "1px solid transparent",
                    }}
                  >
                    <div style={{ fontSize: "12px", fontWeight: "700", color: "#0c211d" }}>{n.title}</div>
                    <div style={{ fontSize: "11.5px", color: "#64748b", margin: "2px 0" }}>{n.desc}</div>
                    <div style={{ fontSize: "10px", color: "#94a3b8" }}>{n.time}</div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Profile Avatar with dropdown */}
        <div style={{ position: "relative" }} ref={userMenuRef}>
          <button
            type="button"
            onClick={() => setShowUserMenu((prev) => !prev)}
            aria-label="Teacher Account Menu"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              background: "transparent",
              border: "none",
              cursor: "pointer",
              padding: "2px",
            }}
          >
            <div style={{ position: "relative" }}>
              <img
                src={trainer.avatar || "/images/student-img-1.jpg"}
                alt={trainer.name}
                style={{
                  width: "36px",
                  height: "36px",
                  borderRadius: "50%",
                  objectFit: "cover",
                  border: "2px solid #10b981",
                }}
              />
              <span
                style={{
                  position: "absolute",
                  bottom: "0",
                  right: "0",
                  width: "9px",
                  height: "9px",
                  borderRadius: "50%",
                  background: "#10b981",
                  border: "1.5px solid #ffffff",
                }}
              />
            </div>
            <div className="db-topbar-user-text" style={{ textAlign: "left" }}>
              <div style={{ fontSize: "12.5px", fontWeight: "700", color: "#0c211d", lineHeight: "1.2" }}>
                {trainer.name}
              </div>
              <div style={{ fontSize: "11px", color: "#64748b", lineHeight: "1.2" }}>
                {trainer.title || "Teacher"}
              </div>
            </div>
          </button>

          {showUserMenu && (
            <div
              style={{
                position: "absolute",
                top: "calc(100% + 8px)",
                right: "0",
                width: "200px",
                background: "#ffffff",
                border: "1px solid var(--sarthi-border, #e8f0eb)",
                borderRadius: "14px",
                boxShadow: "0 16px 36px rgba(12, 33, 29, 0.12)",
                padding: "6px",
                zIndex: 110,
              }}
            >
              <Link
                href="/trainer/settings"
                onClick={() => setShowUserMenu(false)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  padding: "8px 10px",
                  borderRadius: "8px",
                  color: "#0c211d",
                  textDecoration: "none",
                  fontSize: "12.5px",
                  fontWeight: "600",
                }}
              >
                ⚙️ Settings & Profile
              </Link>
              <Link
                href="/dashboard"
                onClick={() => setShowUserMenu(false)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  padding: "8px 10px",
                  borderRadius: "8px",
                  color: "#0c211d",
                  textDecoration: "none",
                  fontSize: "12.5px",
                  fontWeight: "600",
                }}
              >
                🎓 Switch to Student View
              </Link>
              <hr style={{ border: "none", borderTop: "1px solid #e8f0eb", margin: "4px 0" }} />
              <Link
                href="/auth/logout"
                onClick={() => setShowUserMenu(false)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  padding: "8px 10px",
                  borderRadius: "8px",
                  color: "#ef4444",
                  textDecoration: "none",
                  fontSize: "12.5px",
                  fontWeight: "600",
                }}
              >
                🚪 Sign Out
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
